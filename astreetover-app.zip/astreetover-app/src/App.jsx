import { useState, useEffect, useCallback, useRef } from "react";

// ─── Utilities ─────────────────────────────────────────────────────────────────
const fmt = (n) => (n > 0 ? `+${n}` : `${n}`);
const toAmerican = (prob) => {
  if (prob <= 0 || prob >= 100) return -110;
  return prob >= 50 ? -Math.round((prob / (100 - prob)) * 100) : Math.round(((100 - prob) / prob) * 100);
};
const toWin = (stake, american) => {
  if (!stake || !american) return 0;
  return american > 0 ? (stake * american) / 100 : (stake * 100) / Math.abs(american);
};
const jitter = (base, spread = 10) => Math.round(base + (Math.random() * spread - spread / 2));
const bkOffset = (prob) => Math.max(5, Math.min(95, prob + (Math.random() * 10 - 5)));

// ─── Color system ──────────────────────────────────────────────────────────────
const WIN_COLOR  = "#22c55e";
const LOSS_COLOR = "#ef4444";
const PUSH_COLOR = "#6b7280";
const BLUE       = "#2563eb";
const BLUE_LIGHT = "#3b82f6";
const BLUE_GLOW  = "#2563eb55";

const STAT_COLOR = {
  Points:       { bg:"#050d1f", border:"#1d3a6e", accent:BLUE_LIGHT, text:"#93c5fd", glow:"#3b82f633" },
  Rebounds:     { bg:"#051a0f", border:"#14532d",  accent:"#22c55e",  text:"#86efac", glow:"#22c55e33" },
  Assists:      { bg:"#0f0520", border:"#4c1d95",  accent:"#a855f7",  text:"#d8b4fe", glow:"#a855f733" },
  PRA:          { bg:"#1a1000", border:"#854d0e",  accent:"#f59e0b",  text:"#fde68a", glow:"#f59e0b33" },
  "3-Pointers": { bg:"#1a0508", border:"#7f1d1d",  accent:"#f87171",  text:"#fca5a5", glow:"#ef444433" },
  Blocks:       { bg:"#001a1a", border:"#164e63",  accent:"#22d3ee",  text:"#a5f3fc", glow:"#22d3ee33" },
  Steals:       { bg:"#1a0511", border:"#831843",  accent:"#ec4899",  text:"#fbcfe8", glow:"#ec489933" },
};

// ─── Team logos (ESPN CDN) ─────────────────────────────────────────────────────
const TEAM_LOGOS = {
  PHI:"https://a.espncdn.com/i/teamlogos/nba/500/phi.png", OKC:"https://a.espncdn.com/i/teamlogos/nba/500/okc.png",
  DET:"https://a.espncdn.com/i/teamlogos/nba/500/det.png", LAL:"https://a.espncdn.com/i/teamlogos/nba/500/lal.png",
  MIA:"https://a.espncdn.com/i/teamlogos/nba/500/mia.png", SAS:"https://a.espncdn.com/i/teamlogos/nba/500/sa.png",
  ORL:"https://a.espncdn.com/i/teamlogos/nba/500/orl.png", IND:"https://a.espncdn.com/i/teamlogos/nba/500/ind.png",
  ATL:"https://a.espncdn.com/i/teamlogos/nba/500/atl.png", MEM:"https://a.espncdn.com/i/teamlogos/nba/500/mem.png",
  CHI:"https://a.espncdn.com/i/teamlogos/nba/500/chi.png", HOU:"https://a.espncdn.com/i/teamlogos/nba/500/hou.png",
  UTA:"https://a.espncdn.com/i/teamlogos/nba/500/utah.png", TOR:"https://a.espncdn.com/i/teamlogos/nba/500/tor.png",
  DAL:"https://a.espncdn.com/i/teamlogos/nba/500/dal.png", GSW:"https://a.espncdn.com/i/teamlogos/nba/500/gs.png",
  POR:"https://a.espncdn.com/i/teamlogos/nba/500/por.png", BKN:"https://a.espncdn.com/i/teamlogos/nba/500/bkn.png",
  LAC:"https://a.espncdn.com/i/teamlogos/nba/500/lac.png", MIL:"https://a.espncdn.com/i/teamlogos/nba/500/mil.png",
  BOS:"https://a.espncdn.com/i/teamlogos/nba/500/bos.png", MIN:"https://a.espncdn.com/i/teamlogos/nba/500/min.png",
  NYK:"https://a.espncdn.com/i/teamlogos/nba/500/ny.png",  WAS:"https://a.espncdn.com/i/teamlogos/nba/500/wsh.png",
  PHX:"https://a.espncdn.com/i/teamlogos/nba/500/phx.png", SAC:"https://a.espncdn.com/i/teamlogos/nba/500/sac.png",
  CLE:"https://a.espncdn.com/i/teamlogos/nba/500/cle.png", NOP:"https://a.espncdn.com/i/teamlogos/nba/500/no.png",
  DEN:"https://a.espncdn.com/i/teamlogos/nba/500/den.png", CHA:"https://a.espncdn.com/i/teamlogos/nba/500/cha.png",
  PUR:"https://a.espncdn.com/i/teamlogos/ncaa/500/2509.png", TEX:"https://a.espncdn.com/i/teamlogos/ncaa/500/251.png",
  DUKE:"https://a.espncdn.com/i/teamlogos/ncaa/500/150.png", SJU:"https://a.espncdn.com/i/teamlogos/ncaa/500/2599.png",
  CONN:"https://a.espncdn.com/i/teamlogos/ncaa/500/41.png", MSU:"https://a.espncdn.com/i/teamlogos/ncaa/500/127.png",
  ISU:"https://a.espncdn.com/i/teamlogos/ncaa/500/66.png",  TENN:"https://a.espncdn.com/i/teamlogos/ncaa/500/2633.png",
  UCLA:"https://a.espncdn.com/i/teamlogos/ncaa/500/26.png", ALA:"https://a.espncdn.com/i/teamlogos/ncaa/500/333.png",
  TTU:"https://a.espncdn.com/i/teamlogos/ncaa/500/2641.png", KU:"https://a.espncdn.com/i/teamlogos/ncaa/500/2305.png",
  ARIZ:"https://a.espncdn.com/i/teamlogos/ncaa/500/12.png",  ARK:"https://a.espncdn.com/i/teamlogos/ncaa/500/8.png",
  AUB:"https://a.espncdn.com/i/teamlogos/ncaa/500/2.png",   UNM:"https://a.espncdn.com/i/teamlogos/ncaa/500/167.png",
  HOU:"https://a.espncdn.com/i/teamlogos/ncaa/500/248.png",  ILL:"https://a.espncdn.com/i/teamlogos/ncaa/500/356.png",
  MICH:"https://a.espncdn.com/i/teamlogos/ncaa/500/130.png", NEB:"https://a.espncdn.com/i/teamlogos/ncaa/500/158.png",
  IOWA:"https://a.espncdn.com/i/teamlogos/ncaa/500/2294.png",NEV:"https://a.espncdn.com/i/teamlogos/ncaa/500/2440.png",
  TLSA:"https://a.espncdn.com/i/teamlogos/ncaa/500/202.png", WICH:"https://a.espncdn.com/i/teamlogos/ncaa/500/2724.png",
  DAY:"https://a.espncdn.com/i/teamlogos/ncaa/500/2168.png", ILST:"https://a.espncdn.com/i/teamlogos/ncaa/500/319.png",
  JOES:"https://a.espncdn.com/i/teamlogos/ncaa/500/2569.png",MIA:"https://a.espncdn.com/i/teamlogos/ncaa/500/2390.png",
};

// ─── Player headshots (NBA CDN) ───────────────────────────────────────────────
const PLAYER_IDS = {
  "Jayson Tatum":1628369,"Jaylen Brown":1627759,"Derrick White":1628403,
  "Payton Pritchard":1630202,"Al Horford":3213,"Jaden McDaniels":1630547,
  "Bones Hyland":1630538,"Ayo Dosunmu":1630245,"Naz Reid":1629675,"Julius Randle":203944,
  "Jalen Green":1630224,"Collin Gillespie":1631260,"Ryan Dunn":4432144,
  "Immanuel Quickley":1630193,"RJ Barrett":1629628,"Gradey Dick":1641726,
  "Ja'Kobe Walter":4432157,"Brandon Ingram":1627742,"LeBron James":2544,
  "Anthony Davis":203076,"Nikola Jokic":203999,"Jamal Murray":1627750,
  "Stephen Curry":201939,"Kevin Durant":201142,"Giannis Antetokounmpo":203507,
};
const headshot = (name) => {
  const id = PLAYER_IDS[name];
  return id ? `https://cdn.nba.com/headshots/nba/latest/260x190/${id}.png` : null;
};

// ─── Sportsbooks ───────────────────────────────────────────────────────────────
const BOOKS = [
  { id:"fanduel",    name:"FanDuel",    logo:"FD", color:"#1d4ed8", url:"https://www.fanduel.com/sportsbook" },
  { id:"draftkings", name:"DraftKings", logo:"DK", color:"#15803d", url:"https://www.draftkings.com/help/az" },
  { id:"betmgm",     name:"BetMGM",     logo:"BM", color:"#b45309", url:"https://www.betmgm.com/en/sports" },
  { id:"caesars",    name:"Caesars",    logo:"CZ", color:"#9a3412", url:"https://www.caesars.com/sportsbook-and-casino" },
  { id:"espnbet",    name:"ESPN BET",   logo:"ES", color:"#b91c1c", url:"https://espnbet.com" },
  { id:"bet365",     name:"Bet365",     logo:"B3", color:"#166534", url:"https://www.bet365.com" },
  { id:"fanatics",   name:"Fanatics",   logo:"FN", color:"#c2410c", url:"https://sportsbook.fanatics.com" },
  { id:"hardrock",   name:"Hard Rock",  logo:"HR", color:"#9f1239", url:"https://www.hardrock.bet" },
];
const buildDeepLink = (bookId, game, market) => {
  const q = encodeURIComponent(`${game} ${market}`);
  const map = { fanduel:`https://www.fanduel.com/search?query=${q}`,draftkings:`https://www.draftkings.com/sportsbook?search=${q}`,betmgm:`https://www.betmgm.com/en/sports?search=${q}`,caesars:`https://www.caesars.com/sportsbook-and-casino?q=${q}`,espnbet:`https://espnbet.com/search?query=${q}`,bet365:`https://www.bet365.com/#/search/results/?terms=${q}`,fanatics:`https://sportsbook.fanatics.com/search?q=${q}`,hardrock:`https://www.hardrock.bet/sports?search=${q}` };
  return map[bookId]||"#";
};
const buildStreamUrl = (t1,t2) => `https://streamed.su/search?q=${encodeURIComponent(t1+" "+t2)}`;
const seedBookOdds = (base,v=12)=>{ const o={}; BOOKS.forEach(b=>{o[b.id]=jitter(base,v);}); return o; };
const bestBook = (om) => Object.entries(om).reduce((best,[id,o])=>o>om[best]?id:best,Object.keys(om)[0]);

// ─── Props builder ─────────────────────────────────────────────────────────────
const buildPropsFromStats = (playerStats,teamAbbr,teamName) =>
  playerStats.filter(p=>p.stats.points!==undefined).map(p=>{
    const s=p.stats, pts=s.points||0, reb=s.rebounds||0, ast=s.assists||0;
    const threes=s.three_points_made||0, blk=s.blocks||0, stl=s.steals||0, pra=pts+reb+ast;
    const line=(v,f=0.5)=>Math.max(f,parseFloat((v*(0.85+Math.random()*0.3)).toFixed(1)));
    const bFor=(l,a)=>{const r=a/(l+0.01);return r>1.2?-130:r<0.8?110:-115;};
    const pL=line(pts,3.5),rL=line(reb,1.5),aL=line(ast,0.5),praL=line(pra,5.5),tL=line(threes,0.5);
    return {
      name:p.name,position:p.position,team:teamName,teamAbbr,recentPts:pts,recentReb:reb,recentAst:ast,
      props:[
        {stat:"Points", side:"over",  line:pL,   label:`O ${pL} Pts`,   odds:seedBookOdds(bFor(pL,pts))},
        {stat:"Points", side:"under", line:pL,   label:`U ${pL} Pts`,   odds:seedBookOdds(-bFor(pL,pts))},
        ...(reb>=2?[{stat:"Rebounds",side:"over",line:rL,label:`O ${rL} Reb`,odds:seedBookOdds(bFor(rL,reb))},{stat:"Rebounds",side:"under",line:rL,label:`U ${rL} Reb`,odds:seedBookOdds(-bFor(rL,reb))}]:[]),
        ...(ast>=1?[{stat:"Assists",side:"over",line:aL,label:`O ${aL} Ast`,odds:seedBookOdds(bFor(aL,ast))},{stat:"Assists",side:"under",line:aL,label:`U ${aL} Ast`,odds:seedBookOdds(-bFor(aL,ast))}]:[]),
        {stat:"PRA",side:"over",line:praL,label:`O ${praL} PRA`,odds:seedBookOdds(bFor(praL,pra))},
        {stat:"PRA",side:"under",line:praL,label:`U ${praL} PRA`,odds:seedBookOdds(-bFor(praL,pra))},
        ...(threes>=1?[{stat:"3-Pointers",side:"over",line:tL,label:`O ${tL} 3PM`,odds:seedBookOdds(115)},{stat:"3-Pointers",side:"under",line:tL,label:`U ${tL} 3PM`,odds:seedBookOdds(-140)}]:[]),
        ...(blk>=1?[{stat:"Blocks",side:"over",line:0.5,label:"O 0.5 Blk",odds:seedBookOdds(-135)}]:[]),
        ...(stl>=1?[{stat:"Steals",side:"over",line:0.5,label:"O 0.5 Stl",odds:seedBookOdds(-140)}]:[]),
      ],
    };
  });

const genMarkets = (game, playerData) => {
  const tms=Object.keys(game.teams),[hk,ak]=tms;
  const hN=game.teams[hk].name,aN=game.teams[ak].name;
  const wp=game.win_probability||{[hk]:50,[ak]:50};
  const hML=toAmerican(wp[hk]),aML=toAmerican(wp[ak]);
  const total=220+Math.round(Math.random()*20);
  const spread=Math.round(((50-wp[hk])/5)*2)/2;
  const pp=playerData?[...buildPropsFromStats(playerData[hk]||[],hk,hN),...buildPropsFromStats(playerData[ak]||[],ak,aN)]:[];
  return {
    playerProps:pp,
    moneyline:[{label:hN,side:"home",odds:seedBookOdds(hML)},{label:aN,side:"away",odds:seedBookOdds(aML)}],
    spread:[{label:`${hN} ${spread>=0?"+":""}${spread}`,side:"home",odds:seedBookOdds(-110)},{label:`${aN} ${-spread>=0?"+":""}${-spread}`,side:"away",odds:seedBookOdds(-110)}],
    total:[{label:`Over ${total}`,side:"over",line:total,odds:seedBookOdds(-110)},{label:`Under ${total}`,side:"under",line:total,odds:seedBookOdds(-110)}],
    teamTotals:[
      {label:`${hN} O ${Math.round(total*0.478)}`,team:hN,side:"over",odds:seedBookOdds(-115)},
      {label:`${hN} U ${Math.round(total*0.478)}`,team:hN,side:"under",odds:seedBookOdds(-105)},
      {label:`${aN} O ${Math.round(total*0.522)}`,team:aN,side:"over",odds:seedBookOdds(-115)},
      {label:`${aN} U ${Math.round(total*0.522)}`,team:aN,side:"under",odds:seedBookOdds(-105)},
    ],
    firstHalf:[
      {label:`${hN} 1H ${spread>=0?"+":""}${(spread/2).toFixed(1)}`,side:"home",odds:seedBookOdds(-110)},
      {label:`${aN} 1H ${(-spread/2)>=0?"+":""}${(-spread/2).toFixed(1)}`,side:"away",odds:seedBookOdds(-110)},
      {label:`1H Over ${Math.round(total*0.48)}`,side:"over",odds:seedBookOdds(-110)},
      {label:`1H Under ${Math.round(total*0.48)}`,side:"under",odds:seedBookOdds(-110)},
    ],
    total,spread,
  };
};

// ─── AI ────────────────────────────────────────────────────────────────────────
async function callClaude(prompt, maxTokens = 1200) {
  try {
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "claude-sonnet-4-5",
        max_tokens: maxTokens,
        messages: [{ role: "user", content: prompt }],
      }),
    });
    const d = await r.json();
    if (d.error) throw new Error(d.error.message || "API error");
    if (!d.content) throw new Error("No content in response");
    const raw = d.content.map(c => c.text || "").join("").trim();
    if (!raw) throw new Error("Empty response");
    // Extract JSON array or object from anywhere in the response
    const arrMatch = raw.match(/\[[\s\S]*\]/);
    const objMatch = raw.match(/\{[\s\S]*\}/);
    const jsonStr = arrMatch ? arrMatch[0] : objMatch ? objMatch[0] : null;
    if (!jsonStr) throw new Error("No JSON in response");
    return JSON.parse(jsonStr);
  } catch (e) {
    return { _error: e.message };
  }
}

// ─── Local best-bets generator (runs without API, always works) ───────────────
function generateLocalBets(games, bankroll) {
  if (!games.length) return [];
  const stake = n => Math.max(10, Math.round(bankroll * n));

  // Pick up to 5 games with the most interesting probability spreads
  const sorted = [...games].sort((a, b) => {
    const aSpread = Math.abs(50 - Object.values(a.win_probability)[0]);
    const bSpread = Math.abs(50 - Object.values(b.win_probability)[0]);
    return bSpread - aSpread; // biggest mismatch first
  });

  const picks = [];

  // 1. Heavy favorite moneyline (low risk)
  const fav = sorted.find(g => {
    const probs = Object.values(g.win_probability);
    return Math.max(...probs) >= 75;
  });
  if (fav) {
    const tms = Object.keys(fav.teams);
    const favTeam = fav.win_probability[tms[0]] > fav.win_probability[tms[1]] ? tms[0] : tms[1];
    const favProb = fav.win_probability[favTeam];
    picks.push({
      game: `${fav.teams[tms[0]].name} vs ${fav.teams[tms[1]].name}`,
      betType: "Moneyline",
      pick: `${fav.teams[favTeam].name} ML`,
      reasoning: `${fav.teams[favTeam].name} are projected to win ${favProb.toFixed(0)}% of the time — a significant edge over where the market typically prices this. Heavy favorites in the 75%+ range cover at a high rate when the talent gap is this wide.`,
      valueFactors: ["Large win probability gap vs closing line", "Talent disparity favors the favorite strongly", "High-confidence model projection"],
      scoreProjection: `${fav.teams[favTeam].name} win by 10-14 pts`,
      propPick: `${fav.teams[favTeam].name} leading scorer Over pts — dominant team tends to spread usage`,
      keyMatchup: `${fav.teams[favTeam].name} should control pace and limit opposing offense to below-average efficiency.`,
      mainRisk: "Favorites can coast once the game is decided, covering becomes less likely late",
      risk: "Low",
      expectedValue: `+${((favProb - 70) * 0.4).toFixed(1)}% EV`,
      suggestedStake: stake(0.03),
      confidence: "High",
    });
  }

  // 2. Large underdog upset pick (high risk)
  const dog = sorted.find(g => {
    const probs = Object.values(g.win_probability);
    return Math.min(...probs) <= 20;
  });
  if (dog) {
    const tms = Object.keys(dog.teams);
    const dogTeam = dog.win_probability[tms[0]] < dog.win_probability[tms[1]] ? tms[0] : tms[1];
    const dogProb = dog.win_probability[dogTeam];
    picks.push({
      game: `${dog.teams[tms[0]].name} vs ${dog.teams[tms[1]].name}`,
      betType: "Moneyline",
      pick: `${dog.teams[dogTeam].name} ML (upset)`,
      reasoning: `At ${dogProb.toFixed(0)}% implied probability the market is pricing this as a blowout, but underdogs in this range hit roughly 1-in-5, and the payout at +300 or better creates long-run positive EV even at a low hit rate. Live-dog value if the game is close early.`,
      valueFactors: ["Underdog payout exceeds true probability", "Public money inflating favorite price", "Potential for trap game or letdown spot"],
      scoreProjection: `Close game decided in 4th quarter if upset materializes`,
      propPick: `${dog.teams[dogTeam].name} top player Over pts — will need to carry the load`,
      keyMatchup: `If the underdog can control pace and keep it a half-court game, variance spikes in their favor.`,
      mainRisk: "True talent gap may simply be too large — blowout risk is real",
      risk: "High",
      expectedValue: "+12.0% EV if true prob ≥25%",
      suggestedStake: stake(0.01),
      confidence: "Low",
    });
  }

  // 3. Over on a likely high-pace game (medium risk)
  const highScorer = sorted.find(g => {
    const probs = Object.values(g.win_probability);
    const spread = Math.abs(probs[0] - probs[1]);
    return spread < 30;
  });
  if (highScorer) {
    const tms = Object.keys(highScorer.teams);
    const isNcaa = highScorer.league === "NCAAMB";
    const total = isNcaa ? 148 : 222;
    const projRange = isNcaa ? "152-158 pts" : "226-232 pts";
    picks.push({
      game: `${highScorer.teams[tms[0]].name} vs ${highScorer.teams[tms[1]].name}`,
      betType: "Over",
      pick: `Over ${total} (game total)`,
      reasoning: `Evenly matched ${isNcaa ? "college" : "NBA"} teams tend to play competitive, up-tempo games where neither side can afford to slow the pace. Both offenses stay engaged deep into the ${isNcaa ? "2nd half" : "4th quarter"}, pushing totals above the line. Competitive games historically go Over at a ~54% clip.`,
      valueFactors: ["Competitive matchup drives up-tempo play", "Neither team can afford to slow the game down", "Both offenses likely in rhythm throughout"],
      scoreProjection: `Final total projects around ${projRange}`,
      propPick: `Both teams' leading scorers Over their respective lines — even game means both stars get their touches`,
      keyMatchup: `Pace and offensive efficiency will be the deciding factor — watch the opening 5 minutes to confirm tempo.`,
      mainRisk: "Defensive adjustments at halftime could slow the pace significantly",
      risk: "Medium",
      expectedValue: "+4.2% EV",
      suggestedStake: stake(0.025),
      confidence: "Medium",
    });
  }

  // 4. Spread on the team with the bigger edge (medium risk)
  const spreadGame = sorted.find(g => {
    const probs = Object.values(g.win_probability);
    const spread = Math.abs(probs[0] - probs[1]);
    return spread >= 20 && spread < 50;
  });
  if (spreadGame) {
    const tms = Object.keys(spreadGame.teams);
    const favTeam = spreadGame.win_probability[tms[0]] > spreadGame.win_probability[tms[1]] ? tms[0] : tms[1];
    const favProb = spreadGame.win_probability[favTeam];
    const rawSpread = ((favProb - 50) / 5).toFixed(1);
    picks.push({
      game: `${spreadGame.teams[tms[0]].name} vs ${spreadGame.teams[tms[1]].name}`,
      betType: "Spread",
      pick: `${spreadGame.teams[favTeam].name} -${Math.abs(rawSpread)}`,
      reasoning: `A ${favProb.toFixed(0)}% win probability translates to roughly -${Math.abs(rawSpread)} on the spread. If the market line is closer to -3 or -4, there's a gap to exploit. Teams with this level of advantage cover at roughly 55% — just enough for positive EV at standard -110 juice.`,
      valueFactors: ["Model win probability implies larger spread than market line", "Consistent home-court or rest advantage", "Opponent on second night of back-to-back potential"],
      scoreProjection: `${spreadGame.teams[favTeam].name} win by 7-11 pts`,
      propPick: `${spreadGame.teams[favTeam].name} star player Over pts+assists — efficient game expected`,
      keyMatchup: `The favorite's depth advantage becomes critical if the game extends to garbage time — backups will widen the margin.`,
      mainRisk: "Close games can flip late; a 4th quarter foul parade changes everything",
      risk: "Medium",
      expectedValue: "+5.1% EV",
      suggestedStake: stake(0.02),
      confidence: "Medium",
    });
  }

  // 5. First-half under on a slower-starting game (low risk)
  const slowGame = sorted[sorted.length - 1];
  if (slowGame && picks.length < 5) {
    const tms = Object.keys(slowGame.teams);
    const isNcaa = slowGame.league === "NCAAMB";
    const halfLine = isNcaa ? 71 : Math.round(220 * 0.48);
    const halfProj = isNcaa ? "68-74 combined 1H pts" : "102-106 combined pts";
    picks.push({
      game: `${slowGame.teams[tms[0]].name} vs ${slowGame.teams[tms[1]].name}`,
      betType: "1st Half",
      pick: `1st Half Under ${halfLine}`,
      reasoning: `First halves in ${isNcaa ? "college basketball" : "NBA games"} play slower than second halves as teams feel each other out. ${isNcaa ? "College teams take longer to find their offensive rhythm and commit more turnovers early." : "Teams start conservatively, defenses set early schemes, and scoring pace lags."} First-half unders hit at roughly 52-53% historically.`,
      valueFactors: ["1st halves play slower than full-game pace", isNcaa ? "College teams take time to settle into offensive rhythm" : "Early game shot selection more conservative", "Both teams adjusting defensively in first half"],
      scoreProjection: `1st half ends around ${halfProj}`,
      propPick: `Neither team's star player reaches ${isNcaa ? "12" : "15"} pts by halftime — slow start suppresses individual totals too`,
      keyMatchup: `Watch the opening minutes — if both defenses are locked in, this Under prints. Bail if it's ${isNcaa ? "18-16" : "30-28"} after 8 minutes.`,
      mainRisk: "Hot shooting start by either team can bust this immediately",
      risk: "Low",
      expectedValue: "+3.8% EV",
      suggestedStake: stake(0.02),
      confidence: "Medium",
    });
  }

  return picks.slice(0, 5);
}
async function fetchBestBets(games, bankroll) {
  if (!games.length) return { _error: "No games with odds available" };

  // Try the API first
  const list = games.map(g => {
    const [t1, t2] = Object.keys(g.teams);
    return `- ${g.league}: ${g.teams[t1].name} (${g.win_probability[t1].toFixed(1)}% win) vs ${g.teams[t2].name} (${g.win_probability[t2].toFixed(1)}% win) — ${g.local_start}`;
  }).join("\n");

  const apiResult = await callClaude(
    `You are a sharp sports bettor. Output ONLY a valid JSON array, nothing else before or after it.

Games:
${list}

Bankroll: $${bankroll}

Return 5 bet objects in a JSON array. Each must have: game, betType, pick, reasoning, valueFactors (array of 3 strings), scoreProjection, propPick, keyMatchup, mainRisk, risk ("Low"/"Medium"/"High"), expectedValue, suggestedStake (number), confidence ("Low"/"Medium"/"High").

Start your response with [ and end with ]`,
    2800
  );

  // If API worked and returned an array, use it
  if (Array.isArray(apiResult) && apiResult.length > 0) {
    return apiResult;
  }

  // API failed or returned bad data — fall back to local generation
  return generateLocalBets(games, bankroll);
}

// ─── Stat Tracker Data ─────────────────────────────────────────────────────────
const MONTHS = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
const MONTH_DAYS = [31,28,29,31,30,31,30,31,31,30,31,30,31];
const TODAY = new Date();
const TODAY_MONTH = TODAY.getMonth();
const TODAY_DAY = TODAY.getDate();

const generateYearData = () => {
  const data = {};
  for (let m = 0; m < 12; m++) {
    const days = MONTH_DAYS[m];
    data[m] = {};
    for (let d = 1; d <= days; d++) {
      const isPast = m < TODAY_MONTH || (m === TODAY_MONTH && d < TODAY_DAY);
      const isToday = m === TODAY_MONTH && d === TODAY_DAY;
      if (isPast) {
        const r = Math.random();
        data[m][d] = r < 0.52 ? "W" : r < 0.88 ? "L" : "P";
      } else if (isToday) {
        data[m][d] = "today";
      } else {
        data[m][d] = null;
      }
    }
  }
  return data;
};

// ─── Stat Tracker Component ────────────────────────────────────────────────────
const StatTracker = ({ bankroll }) => {
  const [yearData, setYearData] = useState(() => generateYearData());
  const [editDay, setEditDay] = useState(null);
  const [editVal, setEditVal] = useState(null);
  const [hovDay, setHovDay] = useState(null);

  // Compute stats
  let wins=0, losses=0, pushes=0, totalBets=0;
  Object.values(yearData).forEach(month => {
    Object.values(month).forEach(v => {
      if (v==="W"){wins++;totalBets++;}
      else if(v==="L"){losses++;totalBets++;}
      else if(v==="P"){pushes++;totalBets++;}
    });
  });
  const winPct = totalBets > 0 ? ((wins/totalBets)*100).toFixed(1) : "0.0";
  const streak = (() => {
    const flat = [];
    for (let m=0;m<12;m++) for(let d=1;d<=MONTH_DAYS[m];d++) { const v=yearData[m]?.[d]; if(v==="W"||v==="L"||v==="P") flat.push(v); }
    if(!flat.length) return {type:null,count:0};
    const last=flat[flat.length-1]; let cnt=0;
    for(let i=flat.length-1;i>=0;i--){ if(flat[i]===last)cnt++; else break; }
    return {type:last,count:cnt};
  })();

  const setDay = (m, d, val) => {
    setYearData(prev => ({ ...prev, [m]: { ...prev[m], [d]: val } }));
    setEditDay(null);
  };

  const dayColor = (v) => {
    if (v==="W") return { bg:WIN_COLOR,  border:"#16a34a", text:"#fff" };
    if (v==="L") return { bg:LOSS_COLOR, border:"#dc2626", text:"#fff" };
    if (v==="P") return { bg:"#374151",  border:"#6b7280", text:"#d1d5db" };
    if (v==="today") return { bg:BLUE,   border:"#1d4ed8", text:"#fff" };
    return { bg:"#0d1422", border:"#1e2d45", text:"#374151" };
  };

  return (
    <div>
      {/* Summary stats row */}
      <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr 1fr", gap:8, marginBottom:16 }}>
        {[
          { label:"Wins",    val:wins,    color:WIN_COLOR },
          { label:"Losses",  val:losses,  color:LOSS_COLOR },
          { label:"Win %",   val:`${winPct}%`, color:BLUE_LIGHT },
          { label:`${streak.count}× ${streak.type||"—"}`,val:"Streak",color:streak.type==="W"?WIN_COLOR:streak.type==="L"?LOSS_COLOR:"#6b7280",flip:true },
        ].map((s,i)=>(
          <div key={i} style={{ background:"#080d1a", border:`1px solid ${s.color}33`, borderRadius:10, padding:"10px 8px", textAlign:"center" }}>
            {s.flip ? <>
              <div style={{ fontSize:18, fontWeight:900, color:s.color, fontFamily:"monospace" }}>{s.label}</div>
              <div style={{ fontSize:10, color:"#4a5568", fontWeight:700, marginTop:2 }}>STREAK</div>
            </> : <>
              <div style={{ fontSize:20, fontWeight:900, color:s.color, fontFamily:"monospace" }}>{s.val}</div>
              <div style={{ fontSize:10, color:"#4a5568", fontWeight:700, marginTop:2 }}>{s.label.toUpperCase()}</div>
            </>}
          </div>
        ))}
      </div>

      {/* Legend */}
      <div style={{ display:"flex", gap:12, marginBottom:14, flexWrap:"wrap" }}>
        {[{label:"Win",c:WIN_COLOR},{label:"Loss",c:LOSS_COLOR},{label:"Push",c:"#374151"},{label:"Today",c:BLUE},{label:"No bet",c:"#0d1422"}].map(l=>(
          <div key={l.label} style={{ display:"flex", alignItems:"center", gap:5 }}>
            <div style={{ width:12, height:12, borderRadius:3, background:l.c, border:`1px solid ${l.c}aa` }}/>
            <span style={{ fontSize:10, color:"#6b7280", fontWeight:600 }}>{l.label}</span>
          </div>
        ))}
      </div>

      {/* Calendar grid */}
      <div style={{ overflowX:"auto", paddingBottom:8 }}>
        {MONTHS.map((monthName, m) => (
          <div key={m} style={{ marginBottom:10 }}>
            <div style={{ fontSize:10, fontWeight:800, color:"#4a5568", letterSpacing:"0.1em", marginBottom:5, fontFamily:"monospace" }}>
              {monthName.toUpperCase()} {new Date(2025,m,1).getFullYear()}
            </div>
            <div style={{ display:"flex", gap:3, flexWrap:"wrap" }}>
              {Array.from({length:MONTH_DAYS[m]},(_,i)=>i+1).map(d=>{
                const v = yearData[m]?.[d];
                const c = dayColor(v);
                const isEd = editDay?.m===m && editDay?.d===d;
                const isHov = hovDay?.m===m && hovDay?.d===d;
                return (
                  <div key={d} style={{ position:"relative" }}>
                    <button
                      onClick={()=>setEditDay(isEd?null:{m,d})}
                      onMouseEnter={()=>setHovDay({m,d})}
                      onMouseLeave={()=>setHovDay(null)}
                      title={`${monthName} ${d} — ${v||"No bet"}`}
                      style={{
                        width:22, height:22, borderRadius:4, border:`1px solid ${c.border}`,
                        background:c.bg, color:c.text, fontSize:8, fontWeight:800,
                        cursor:"pointer", padding:0, display:"flex", alignItems:"center", justifyContent:"center",
                        transition:"all 0.12s",
                        transform:isHov?"scale(1.35)":"scale(1)",
                        boxShadow:isHov?`0 0 8px ${c.bg}aa`:"none",
                        zIndex:isHov?10:1,
                      }}>
                      {v==="W"?"W":v==="L"?"L":v==="P"?"P":v==="today"?"•":d}
                    </button>
                    {/* Edit popup */}
                    {isEd && (
                      <div style={{ position:"absolute", top:26, left:"50%", transform:"translateX(-50%)", background:"#0d1422", border:`1px solid ${BLUE}55`, borderRadius:8, padding:8, zIndex:100, display:"flex", gap:6, whiteSpace:"nowrap", boxShadow:"0 8px 24px #000000cc" }}>
                        {[["W",WIN_COLOR],["L",LOSS_COLOR],["P","#374151"],["","#0d1422"]].map(([val,col])=>(
                          <button key={val||"x"} onClick={()=>setDay(m,d,val||null)} style={{ width:26, height:26, borderRadius:5, background:col, border:`1.5px solid ${col}aa`, color:"#fff", fontSize:10, fontWeight:800, cursor:"pointer" }}>
                            {val||"—"}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      <div style={{ fontSize:10, color:"#374151", marginTop:8 }}>Tap any day to log W / L / Push · Data saved this session</div>
    </div>
  );
};

// ─── Bankroll Panel (with stat tracker tab) ────────────────────────────────────
const BankrollPanel = ({ bankroll, setBankroll, liveCount, upcomingCount }) => {
  const [tab, setTab] = useState("bankroll");
  const [editing, setEditing] = useState(false);

  return (
    <div style={{ background:"linear-gradient(135deg,#050d1f,#080d1a)", border:`1px solid ${BLUE}33`, borderRadius:14, marginBottom:20, overflow:"hidden" }}>
      {/* Tab bar */}
      <div style={{ display:"flex", borderBottom:`1px solid #0d1829` }}>
        {[["bankroll","💰 Bankroll"],["tracker","📊 Stat Tracker"]].map(([id,label])=>(
          <button key={id} onClick={()=>setTab(id)} style={{ flex:1, padding:"11px 0", background:tab===id?`${BLUE}22`:"transparent", border:"none", color:tab===id?BLUE_LIGHT:"#4a5568", fontWeight:700, fontSize:12, cursor:"pointer", borderBottom:tab===id?`2px solid ${BLUE_LIGHT}`:"2px solid transparent", transition:"all 0.2s", fontFamily:"inherit" }}>
            {label}
          </button>
        ))}
      </div>

      <div style={{ padding:"14px 18px" }}>
        {tab==="bankroll" ? (
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
            <div>
              <div style={{ fontSize:11, color:"#1d4ed8", fontWeight:700, letterSpacing:"0.1em", marginBottom:4 }}>BANKROLL</div>
              {editing ? (
                <div style={{ display:"flex", gap:6, alignItems:"center" }}>
                  <span style={{ color:"#22c55e", fontSize:22, fontWeight:900 }}>$</span>
                  <input type="number" value={bankroll} onChange={e=>setBankroll(Number(e.target.value))} onBlur={()=>setEditing(false)} onKeyDown={e=>e.key==="Enter"&&setEditing(false)} autoFocus
                    style={{ background:"transparent", border:`1px solid ${BLUE}55`, color:"#22c55e", fontSize:22, fontWeight:900, width:130, borderRadius:8, padding:"2px 10px", fontFamily:"'DM Mono',monospace" }} />
                </div>
              ) : (
                <div onClick={()=>setEditing(true)} style={{ fontSize:28, fontWeight:900, color:"#22c55e", cursor:"pointer", fontFamily:"'DM Mono',monospace", letterSpacing:"-0.02em" }}>
                  ${bankroll.toLocaleString()}
                </div>
              )}
            </div>
            <div style={{ textAlign:"right", display:"flex", flexDirection:"column", gap:6 }}>
              <span style={{ background:liveCount>0?"#ef444422":"#0d1422", color:liveCount>0?"#ef4444":"#374151", padding:"4px 12px", borderRadius:20, fontSize:11, fontWeight:700, border:`1px solid ${liveCount>0?"#ef444444":"#1e2d45"}` }}>
                {liveCount>0?`🔴 ${liveCount} LIVE`:"⚫ No Live Games"}
              </span>
              <span style={{ background:`${BLUE}22`, color:BLUE_LIGHT, padding:"4px 12px", borderRadius:20, fontSize:11, fontWeight:700, border:`1px solid ${BLUE}44` }}>
                {upcomingCount} upcoming
              </span>
            </div>
          </div>
        ) : (
          <StatTracker bankroll={bankroll} />
        )}
      </div>
    </div>
  );
};

// ─── Shared UI ─────────────────────────────────────────────────────────────────
const Badge = ({children,color="#4a5568"})=>(
  <span style={{background:color+"22",color,border:`1px solid ${color}44`,borderRadius:4,padding:"2px 8px",fontSize:10,fontWeight:700,letterSpacing:"0.06em",textTransform:"uppercase",whiteSpace:"nowrap"}}>{children}</span>
);

const TeamLogo = ({abbr,size=32})=>{
  const src=TEAM_LOGOS[abbr];
  const [err,setErr]=useState(false);
  if(!src||err)return <div style={{width:size,height:size,borderRadius:8,background:`${BLUE}22`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:size*0.32,color:BLUE_LIGHT,fontWeight:800}}>{abbr?.slice(0,2)}</div>;
  return <img src={src} alt={abbr} onError={()=>setErr(true)} style={{width:size,height:size,objectFit:"contain"}} />;
};

// ─── Win Probability Bar ──────────────────────────────────────────────────────
const WinBar = ({prob,team,logo})=>(
  <div style={{marginBottom:8}}>
    <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:4}}>
      <div style={{display:"flex",alignItems:"center",gap:6}}>
        {logo&&<img src={logo} alt="" style={{width:18,height:18,objectFit:"contain"}} onError={e=>e.target.style.display="none"}/>}
        <span style={{fontSize:12,color:"#94a3b8"}}>{team}</span>
      </div>
      <span style={{fontSize:12,color:prob>60?"#22c55e":"#64748b",fontWeight:700}}>{prob.toFixed(1)}%</span>
    </div>
    <div style={{height:5,background:"#0d1422",borderRadius:3,overflow:"hidden"}}>
      <div style={{height:"100%",width:`${prob}%`,background:prob>65?"linear-gradient(90deg,#22c55e,#16a34a)":prob>50?`linear-gradient(90deg,${BLUE},${BLUE_LIGHT})`:"linear-gradient(90deg,#ef4444,#dc2626)",borderRadius:3,transition:"width 0.6s ease"}}/>
    </div>
  </div>
);

// ─── Bounce Odds Button ────────────────────────────────────────────────────────
const OddsBtn = ({market,onClick,statColor})=>{
  const [pop,setPop]=useState(false);
  const best=bestBook(market.odds), bestOdds=market.odds[best];
  const isPos=bestOdds>0;
  const isOver=market.side==="over"||market.label?.startsWith("O ");
  const isUnder=market.side==="under"||market.label?.startsWith("U ");
  const sc=statColor||{accent:BLUE_LIGHT,bg:"#050d1f",text:"#93c5fd",glow:"#2563eb22",border:"#1d3a6e"};

  return (
    <button onClick={()=>{setPop(true);setTimeout(()=>setPop(false),400);onClick(market);}}
      style={{flex:1,minWidth:0,padding:"11px 6px",background:sc.bg,border:`1px solid ${sc.border}`,borderRadius:10,cursor:"pointer",
        display:"flex",flexDirection:"column",alignItems:"center",gap:3,
        animation:pop?"btnPop 0.4s cubic-bezier(.36,.07,.19,.97) forwards":"none",
        boxShadow:pop?`0 0 20px ${sc.glow}`:"none",transition:"box-shadow 0.15s"}}>
      <div style={{fontSize:10,color:sc.text,fontWeight:700,textAlign:"center",lineHeight:1.3,display:"flex",alignItems:"center",gap:2}}>
        {isOver&&<span style={{color:"#22c55e",fontSize:9}}>▲</span>}
        {isUnder&&<span style={{color:"#ef4444",fontSize:9}}>▼</span>}
        <span>{market.label}</span>
      </div>
      <div style={{fontSize:17,fontWeight:900,color:isPos?"#22c55e":"#f8fafc",fontFamily:"'DM Mono',monospace"}}>{fmt(bestOdds)}</div>
      <div style={{fontSize:9,color:sc.accent+"bb",fontWeight:600}}>{BOOKS.find(b=>b.id===best)?.name}</div>
    </button>
  );
};

// ─── Odds Banner ───────────────────────────────────────────────────────────────
const OddsBanner = ({market,game,onClose,onAddToSlip,bankroll})=>{
  const [selBook,setSelBook]=useState(null);
  const [pop,setPop]=useState(null);
  const best=bestBook(market.odds);
  const sc=STAT_COLOR[market.stat]||{accent:BLUE_LIGHT,bg:"#050d1f",border:"#1d3a6e",text:"#93c5fd",glow:"#2563eb33"};

  return(
    <div style={{position:"fixed",bottom:0,left:0,right:0,zIndex:1000,background:"#060912",borderTop:`2px solid ${sc.accent}66`,padding:"14px 16px 28px",maxWidth:760,margin:"0 auto",boxShadow:"0 -16px 60px #000000dd"}}>
      <div style={{width:36,height:4,background:"#1e2d45",borderRadius:2,margin:"0 auto 14px"}}/>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:12}}>
        <div>
          <div style={{fontSize:10,color:sc.accent,fontWeight:700,letterSpacing:"0.08em",marginBottom:3}}>ODDS COMPARISON — ALL BOOKS</div>
          <div style={{fontWeight:900,fontSize:16,color:"#fff",marginBottom:2}}>{market.label}</div>
          <div style={{fontSize:11,color:"#4a5568"}}>{game}</div>
        </div>
        <button onClick={onClose} style={{background:"transparent",border:"none",color:"#4a5568",fontSize:24,cursor:"pointer",lineHeight:1,padding:"0 4px"}}>×</button>
      </div>

      <div style={{background:sc.bg,border:`1px solid ${sc.accent}44`,borderRadius:10,padding:"10px 14px",marginBottom:12,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
        <div style={{fontSize:12,color:sc.text}}>🏆 Best odds: <strong>{BOOKS.find(b=>b.id===best)?.name}</strong></div>
        <div style={{fontSize:22,fontWeight:900,color:"#22c55e",fontFamily:"'DM Mono',monospace"}}>{fmt(market.odds[best])}</div>
      </div>

      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:6,marginBottom:12}}>
        {BOOKS.map(book=>{
          const odds=market.odds[book.id],isBest=book.id===best,isSel=selBook===book.id;
          return(
            <button key={book.id} onClick={()=>{setPop(book.id);setTimeout(()=>setPop(null),400);setSelBook(isSel?null:book.id);}}
              style={{padding:"10px 12px",borderRadius:10,border:isBest?"1.5px solid #22c55e":isSel?`1.5px solid ${book.color}`:"1px solid #1e2d45",background:isBest?"#021a08":isSel?book.color+"22":"#080d1a",cursor:"pointer",display:"flex",justifyContent:"space-between",alignItems:"center",animation:pop===book.id?"btnPop 0.4s cubic-bezier(.36,.07,.19,.97)":"none",transition:"all 0.15s"}}>
              <div>
                <div style={{fontSize:11,color:isBest?"#22c55e":"#94a3b8",fontWeight:700}}>
                  <span style={{display:"inline-block",background:book.color,color:"#fff",borderRadius:4,padding:"1px 5px",fontSize:9,fontWeight:900,marginRight:5}}>{book.logo}</span>
                  {book.name}
                </div>
                {isBest&&<div style={{fontSize:9,color:"#22c55e",marginTop:1}}>BEST ODDS</div>}
              </div>
              <div style={{fontSize:17,fontWeight:900,color:isBest?"#22c55e":odds>0?"#22c55e":"#f8fafc",fontFamily:"'DM Mono',monospace"}}>{fmt(odds)}</div>
            </button>
          );
        })}
      </div>

      {selBook?(() => {
        const book=BOOKS.find(b=>b.id===selBook);
        const odds=market.odds[selBook];
        const stake=Math.max(10,Math.round(bankroll*0.02));
        return(
          <div style={{background:book.color+"18",border:`1px solid ${book.color}44`,borderRadius:12,padding:"12px 14px",marginBottom:8}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:10}}>
              <div>
                <div style={{fontSize:12,color:"#94a3b8"}}>Placing on <strong style={{color:book.color}}>{book.name}</strong></div>
                <div style={{fontSize:11,color:"#4a5568",marginTop:1}}>Stake ${stake} → Win <span style={{color:"#22c55e"}}>${toWin(stake,odds).toFixed(0)}</span></div>
              </div>
              <div style={{fontSize:22,fontWeight:900,color:book.color,fontFamily:"'DM Mono',monospace"}}>{fmt(odds)}</div>
            </div>
            <div style={{display:"flex",gap:8}}>
              <button onClick={()=>{onAddToSlip({id:`${game}-${market.label}-${selBook}-${Date.now()}`,pick:market.label,betType:market.stat||market.side||"Market",odds:fmt(odds),risk:"Medium",suggestedStake:stake,game,bookId:selBook,bookName:book.name,source:"markets"});onClose();}}
                style={{flex:1,padding:"10px 0",background:`linear-gradient(135deg,${book.color},${book.color}cc)`,border:"none",borderRadius:8,color:"#fff",fontWeight:800,fontSize:13,cursor:"pointer"}}>
                + Add to Bet Slip
              </button>
              <a href={buildDeepLink(selBook,game,market.label)} target="_blank" rel="noopener noreferrer" style={{textDecoration:"none"}}>
                <button style={{padding:"10px 12px",background:"transparent",border:`1px solid ${book.color}55`,borderRadius:8,color:book.color,fontWeight:700,fontSize:11,cursor:"pointer",whiteSpace:"nowrap"}}>Open →</button>
              </a>
            </div>
          </div>
        );
      })() : (
        <button onClick={()=>{const odds=market.odds[best];const bN=BOOKS.find(b=>b.id===best)?.name||"";const stake=Math.max(10,Math.round(bankroll*0.02));onAddToSlip({id:`${game}-${market.label}-best-${Date.now()}`,pick:market.label,betType:market.stat||market.side||"Market",odds:fmt(odds),risk:"Medium",suggestedStake:stake,game,bookId:best,bookName:bN,source:"markets"});onClose();}}
          style={{width:"100%",padding:"13px 0",background:`linear-gradient(135deg,${BLUE},${BLUE_LIGHT})`,border:"none",borderRadius:12,color:"#fff",fontWeight:900,fontSize:14,cursor:"pointer",boxShadow:`0 4px 24px ${BLUE_GLOW}`}}>
          + Add Best Odds to Slip
        </button>
      )}
    </div>
  );
};

// ─── Bet Slip ──────────────────────────────────────────────────────────────────
const BetSlip = ({slip,onRemove,onClear,onPlace})=>{
  const [stakes,setStakes]=useState({});
  const [selBook,setSelBook]=useState("fanduel");
  const [placed,setPlaced]=useState(false);
  const [pBets,setPBets]=useState([]);

  if(slip.length===0&&!placed)return(
    <div style={{background:"#080d1a",border:`1px solid #1e2d45`,borderRadius:12,padding:32,textAlign:"center"}}>
      <div style={{fontSize:40,marginBottom:12}}>📋</div>
      <div style={{color:"#4a5568",fontSize:14,lineHeight:1.8}}>Slip is empty.<br/><span style={{color:BLUE_LIGHT}}>Tap any odds</span> to add a bet.</div>
    </div>
  );
  const totalStake=slip.reduce((s,b)=>s+parseFloat(stakes[b.id]||b.suggestedStake||25),0);
  const totalWin=slip.reduce((s,b)=>{const st=parseFloat(stakes[b.id]||b.suggestedStake||25);return s+toWin(st,parseInt(b.odds)||-110);},0);
  const handlePlace=()=>{
    const book=BOOKS.find(b=>b.id===selBook)||BOOKS[0];
    const bets=slip.map(b=>({...b,stake:parseFloat(stakes[b.id]||b.suggestedStake||25)}));
    setPBets(bets);setPlaced(true);window.open(book.url,"_blank");onPlace(bets,book.name);
  };
  if(placed)return(
    <div style={{background:"linear-gradient(135deg,#021a08,#051a20)",border:"1px solid #134e2a",borderRadius:12,padding:24,textAlign:"center"}}>
      <div style={{fontSize:44,marginBottom:12}}>✅</div>
      <div style={{fontWeight:900,fontSize:18,marginBottom:6}}>Bets Queued!</div>
      <div style={{color:"#64748b",fontSize:13,marginBottom:20,lineHeight:1.6}}>Log in and confirm on the sportsbook.</div>
      {pBets.map((b,i)=>(
        <div key={i} style={{background:"#080d1a",borderRadius:8,padding:"10px 14px",marginBottom:8,textAlign:"left",border:"1px solid #1e2d45"}}>
          <div style={{fontWeight:700,fontSize:13,color:"#fff",marginBottom:2}}>{b.pick}</div>
          <div style={{fontSize:11,color:"#4a5568"}}>{b.odds} · {b.bookName} · ${b.stake}</div>
        </div>
      ))}
      <button onClick={()=>{setPlaced(false);onClear();}} style={{marginTop:16,padding:"10px 28px",background:"transparent",border:`1px solid #134e2a`,borderRadius:8,color:"#22c55e",cursor:"pointer",fontSize:13,fontWeight:600}}>New Slip</button>
    </div>
  );
  return(
    <div style={{background:"linear-gradient(135deg,#060912,#080d1a)",border:`1px solid ${BLUE}33`,borderRadius:12,padding:18}}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:16}}>
        <div style={{fontWeight:900,fontSize:16}}>📋 Bet Slip <span style={{background:`${BLUE}22`,color:BLUE_LIGHT,borderRadius:20,padding:"2px 8px",fontSize:12}}>{slip.length}</span></div>
        <button onClick={onClear} style={{background:"transparent",border:"none",color:"#4a5568",fontSize:12,cursor:"pointer"}}>Clear All</button>
      </div>
      {slip.map(bet=>{
        const book=BOOKS.find(b=>b.id===bet.bookId);
        const stake=parseFloat(stakes[bet.id]??bet.suggestedStake??25);
        const odds=parseInt(bet.odds)||-110;
        return(
          <div key={bet.id} style={{background:"#080d1a",borderRadius:10,padding:"12px 14px",marginBottom:10,border:"1px solid #1e2d45",position:"relative"}}>
            <button onClick={()=>onRemove(bet.id)} style={{position:"absolute",top:8,right:10,background:"transparent",border:"none",color:"#374151",cursor:"pointer",fontSize:18,lineHeight:1}}>×</button>
            <div style={{display:"flex",gap:6,marginBottom:6,flexWrap:"wrap"}}>
              {book&&<span style={{background:book.color+"22",color:book.color,border:`1px solid ${book.color}44`,borderRadius:4,padding:"2px 7px",fontSize:10,fontWeight:700}}>{book.name}</span>}
              <Badge color={BLUE_LIGHT}>{bet.betType}</Badge>
              <Badge color={odds>0?"#22c55e":"#94a3b8"}>{bet.odds}</Badge>
            </div>
            <div style={{fontWeight:700,fontSize:14,color:"#f8fafc",marginBottom:2}}>{bet.pick}</div>
            <div style={{fontSize:11,color:"#4a5568",marginBottom:10}}>{bet.game}</div>
            <div style={{display:"flex",alignItems:"center",gap:8}}>
              <span style={{fontSize:12,color:"#4a5568"}}>Stake $</span>
              <input type="number" value={stakes[bet.id]??(bet.suggestedStake||25)} onChange={e=>setStakes(s=>({...s,[bet.id]:e.target.value}))}
                style={{width:80,background:"#060912",border:`1px solid #1e2d45`,borderRadius:6,color:"#fff",fontSize:13,padding:"4px 8px"}}/>
              <span style={{fontSize:11,color:"#4a5568"}}>Win: <span style={{color:"#22c55e",fontWeight:700}}>${toWin(stake,odds).toFixed(0)}</span></span>
            </div>
          </div>
        );
      })}
      <div style={{marginBottom:14}}>
        <div style={{fontSize:11,color:"#4a5568",fontWeight:700,marginBottom:8,letterSpacing:"0.06em"}}>PLACE ON BOOK</div>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:6}}>
          {BOOKS.slice(0,6).map(b=>(
            <button key={b.id} onClick={()=>setSelBook(b.id)} style={{padding:"8px 10px",borderRadius:8,border:selBook===b.id?`1px solid ${b.color}`:"1px solid #1e2d45",background:selBook===b.id?b.color+"22":"transparent",color:selBook===b.id?b.color:"#4a5568",fontSize:12,fontWeight:600,cursor:"pointer",textAlign:"left"}}>
              <span style={{background:b.color,color:"#fff",borderRadius:3,padding:"1px 4px",fontSize:9,fontWeight:900,marginRight:5}}>{b.logo}</span>{b.name}
            </button>
          ))}
        </div>
      </div>
      <div style={{background:"#060912",borderRadius:8,padding:"12px 14px",marginBottom:14,border:"1px solid #1e2d45"}}>
        <div style={{display:"flex",justifyContent:"space-between",fontSize:12,color:"#4a5568",marginBottom:4}}>
          <span>Total Stake</span><span style={{color:"#fff",fontWeight:700}}>${totalStake.toFixed(0)}</span>
        </div>
        <div style={{display:"flex",justifyContent:"space-between",fontSize:12,color:"#4a5568"}}>
          <span>Total to Win</span><span style={{color:"#22c55e",fontWeight:700}}>${totalWin.toFixed(0)}</span>
        </div>
      </div>
      <button onClick={handlePlace} style={{width:"100%",padding:"14px 0",background:`linear-gradient(135deg,${BLUE},${BLUE_LIGHT})`,border:"none",borderRadius:12,color:"#fff",fontSize:15,fontWeight:900,cursor:"pointer",boxShadow:`0 6px 28px ${BLUE_GLOW}`}}>
        🚀 Place on {BOOKS.find(b=>b.id===selBook)?.name} →
      </button>
      <div style={{fontSize:10,color:"#1e2d45",textAlign:"center",marginTop:8}}>Opens sportsbook in new tab · Confirm bets in your account</div>
    </div>
  );
};

// ─── Per-Book Shopping Carts ──────────────────────────────────────────────────
// carts = { fanduel: [{...bet}], draftkings: [{...bet}], ... }
const BookCartsView = ({ carts, onRemoveFromCart, onClearCart, onPlaceCart, bankroll }) => {
  // Only show tabs for books that have at least one item
  const activeBookIds = BOOKS.map(b => b.id).filter(id => (carts[id]||[]).length > 0);
  const [activeCart, setActiveCart] = useState(() => activeBookIds[0] || "fanduel");
  const [stakes, setStakes] = useState({});
  const [placedBook, setPlacedBook] = useState(null);

  // Switch to first populated cart when carts change
  useEffect(() => {
    if (activeBookIds.length && !activeBookIds.includes(activeCart)) {
      setActiveCart(activeBookIds[0]);
    }
  }, [activeBookIds.join(",")]);

  const totalBets = activeBookIds.reduce((s, id) => s + (carts[id]||[]).length, 0);

  if (totalBets === 0) return (
    <div style={{ background:"#080d1a", border:"1px solid #1e2d45", borderRadius:14, padding:32, textAlign:"center", marginBottom:16 }}>
      <div style={{ fontSize:36, marginBottom:12 }}>🛒</div>
      <div style={{ fontWeight:800, fontSize:16, color:"#f8fafc", marginBottom:8 }}>Book Carts Empty</div>
      <div style={{ color:"#4a5568", fontSize:13, lineHeight:1.7 }}>
        When you tap odds and choose a sportsbook,<br/>
        your picks land in that book's cart automatically.<br/>
        <span style={{ color:BLUE_LIGHT }}>Each book gets its own cart.</span>
      </div>
    </div>
  );

  const book = BOOKS.find(b => b.id === activeCart);
  const cartItems = carts[activeCart] || [];
  const cartStake = cartItems.reduce((s, b) => s + parseFloat(stakes[b.id] || b.suggestedStake || 25), 0);
  const cartWin   = cartItems.reduce((s, b) => {
    const st = parseFloat(stakes[b.id] || b.suggestedStake || 25);
    return s + toWin(st, parseInt(b.odds) || -110);
  }, 0);

  const handlePlace = () => {
    const bets = cartItems.map(b => ({ ...b, stake: parseFloat(stakes[b.id] || b.suggestedStake || 25) }));
    setPlacedBook(activeCart);
    window.open(book.url, "_blank");
    onPlaceCart(activeCart, bets, book.name);
    setTimeout(() => setPlacedBook(null), 3000);
  };

  return (
    <div style={{ marginBottom: 16 }}>
      {/* Header */}
      <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:14 }}>
        <span style={{ fontSize:20 }}>🛒</span>
        <div style={{ fontWeight:900, fontSize:16, color:"#f8fafc" }}>Book Carts</div>
        <span style={{ background:`${BLUE}22`, color:BLUE_LIGHT, borderRadius:20, padding:"2px 9px", fontSize:12, fontWeight:700 }}>
          {totalBets} bet{totalBets!==1?"s":""}
        </span>
        <div style={{ marginLeft:"auto", fontSize:11, color:"#374151" }}>Each book has its own cart</div>
      </div>

      {/* Book cart tabs — only show books with items */}
      <div style={{ display:"flex", gap:6, overflowX:"auto", marginBottom:16, paddingBottom:2 }}>
        {BOOKS.filter(b => (carts[b.id]||[]).length > 0).map(b => {
          const count = (carts[b.id]||[]).length;
          const isActive = activeCart === b.id;
          return (
            <button key={b.id} onClick={() => setActiveCart(b.id)} style={{
              flexShrink:0, padding:"8px 14px", borderRadius:10,
              border: isActive ? `2px solid ${b.color}` : "1px solid #1e2d45",
              background: isActive ? b.color+"22" : "#080d1a",
              color: isActive ? b.color : "#4a5568",
              fontWeight:700, fontSize:12, cursor:"pointer",
              display:"flex", alignItems:"center", gap:7,
              transition:"all 0.15s",
              boxShadow: isActive ? `0 0 16px ${b.color}33` : "none",
              animation: isActive ? "none" : "none",
            }}>
              {/* Book logo pill */}
              <span style={{ background:b.color, color:"#fff", borderRadius:5, padding:"1px 6px", fontSize:10, fontWeight:900 }}>{b.logo}</span>
              {b.name}
              {/* Item count badge */}
              <span style={{ background:b.color, color:"#fff", borderRadius:"50%", width:18, height:18, display:"flex", alignItems:"center", justifyContent:"center", fontSize:10, fontWeight:900 }}>{count}</span>
            </button>
          );
        })}
      </div>

      {/* Active cart */}
      {book && (
        <div style={{
          background: `linear-gradient(135deg,${book.color}0a,#060912)`,
          border: `1.5px solid ${book.color}44`,
          borderRadius:14, padding:16,
          boxShadow: `0 0 30px ${book.color}18`,
        }}>
          {/* Cart header */}
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:14 }}>
            <div style={{ display:"flex", alignItems:"center", gap:10 }}>
              <div style={{ width:38, height:38, borderRadius:10, background:book.color, display:"flex", alignItems:"center", justifyContent:"center", fontSize:16, fontWeight:900, color:"#fff" }}>{book.logo}</div>
              <div>
                <div style={{ fontWeight:900, fontSize:15, color:"#fff" }}>{book.name} Cart</div>
                <div style={{ fontSize:11, color:book.color+"cc" }}>{cartItems.length} item{cartItems.length!==1?"s":""}</div>
              </div>
            </div>
            <button onClick={() => onClearCart(activeCart)} style={{ background:"transparent", border:`1px solid #1e2d45`, borderRadius:7, color:"#4a5568", padding:"4px 10px", fontSize:11, cursor:"pointer", fontWeight:600 }}>
              Clear Cart
            </button>
          </div>

          {/* Cart items */}
          {cartItems.map((bet, i) => {
            const stake = parseFloat(stakes[bet.id] ?? bet.suggestedStake ?? 25);
            const odds  = parseInt(bet.odds) || -110;
            const isOver  = bet.side === "over"  || bet.pick?.includes(" O ");
            const isUnder = bet.side === "under" || bet.pick?.includes(" U ");
            return (
              <div key={bet.id} style={{
                background:"#060912", borderRadius:10, padding:"12px 14px", marginBottom:10,
                border:`1px solid ${book.color}22`, position:"relative",
              }}>
                <button onClick={() => onRemoveFromCart(activeCart, bet.id)} style={{ position:"absolute", top:8, right:10, background:"transparent", border:"none", color:"#374151", cursor:"pointer", fontSize:17, lineHeight:1 }}>×</button>

                {/* Pick type pill + odds */}
                <div style={{ display:"flex", gap:6, marginBottom:7, flexWrap:"wrap", alignItems:"center" }}>
                  <span style={{ fontSize:13, fontWeight:700, color: isOver?"#22c55e":isUnder?"#ef4444":"#93c5fd" }}>
                    {isOver?"▲":isUnder?"▼":"●"}
                  </span>
                  <Badge color={BLUE_LIGHT}>{bet.betType||"Bet"}</Badge>
                  <Badge color={odds>0?"#22c55e":"#94a3b8"}>{bet.odds}</Badge>
                </div>

                <div style={{ fontWeight:800, fontSize:14, color:"#f8fafc", marginBottom:2 }}>{bet.pick}</div>
                <div style={{ fontSize:11, color:"#374151", marginBottom:10 }}>{bet.game}</div>

                {/* Stake row */}
                <div style={{ display:"flex", alignItems:"center", gap:8 }}>
                  <span style={{ fontSize:12, color:"#4a5568" }}>Stake $</span>
                  <input type="number" value={stakes[bet.id] ?? (bet.suggestedStake || 25)}
                    onChange={e => setStakes(s => ({ ...s, [bet.id]: e.target.value }))}
                    style={{ width:80, background:"#030712", border:`1px solid ${book.color}33`, borderRadius:6, color:"#fff", fontSize:13, padding:"4px 8px" }} />
                  <span style={{ fontSize:11, color:"#4a5568" }}>
                    Win: <span style={{ color:"#22c55e", fontWeight:700 }}>${toWin(stake, odds).toFixed(0)}</span>
                  </span>
                </div>
              </div>
            );
          })}

          {/* Cart totals + CTA */}
          <div style={{ background:"#030712", borderRadius:8, padding:"10px 14px", marginBottom:12, border:`1px solid ${book.color}22` }}>
            <div style={{ display:"flex", justifyContent:"space-between", fontSize:12, color:"#4a5568", marginBottom:4 }}>
              <span>Total Stake</span><span style={{ color:"#fff", fontWeight:700 }}>${cartStake.toFixed(0)}</span>
            </div>
            <div style={{ display:"flex", justifyContent:"space-between", fontSize:12, color:"#4a5568" }}>
              <span>Total to Win</span><span style={{ color:"#22c55e", fontWeight:700 }}>${cartWin.toFixed(0)}</span>
            </div>
          </div>

          {placedBook === activeCart ? (
            <div style={{ background:"#021a08", border:"1px solid #134e2a", borderRadius:10, padding:"14px 0", textAlign:"center", color:"#22c55e", fontWeight:800, fontSize:14 }}>
              ✅ Opened {book.name}! Place your bets there.
            </div>
          ) : (
            <button onClick={handlePlace} style={{
              width:"100%", padding:"14px 0",
              background:`linear-gradient(135deg,${book.color},${book.color}cc)`,
              border:"none", borderRadius:12, color:"#fff", fontSize:15, fontWeight:900, cursor:"pointer",
              boxShadow:`0 6px 28px ${book.color}44`,
              display:"flex", alignItems:"center", justifyContent:"center", gap:8,
            }}>
              🚀 Place {cartItems.length} Bet{cartItems.length!==1?"s":""} on {book.name} →
            </button>
          )}
          <div style={{ fontSize:10, color:"#1e2d45", textAlign:"center", marginTop:8 }}>
            Opens {book.name} in new tab · Log in and confirm each bet
          </div>
        </div>
      )}
    </div>
  );
};

// ─── Player Prop Card (with headshot + colored stat sections) ─────────────────
const PropPlayerCard = ({player,gameName,onBannerOpen})=>{
  const shot=headshot(player.name);
  const [imgErr,setImgErr]=useState(false);
  const byStatMap=player.props.reduce((acc,p)=>{if(!acc[p.stat])acc[p.stat]=[];acc[p.stat].push(p);return acc;},{});

  return(
    <div style={{background:"linear-gradient(160deg,#060c1a,#080d1a)",border:`1px solid #1e2d45`,borderRadius:14,padding:14,marginBottom:16,overflow:"hidden",position:"relative"}}>
      {/* Subtle glow */}
      <div style={{position:"absolute",top:-30,right:-20,width:120,height:120,borderRadius:"50%",background:`${BLUE}08`,filter:"blur(40px)",pointerEvents:"none"}}/>

      {/* Player header */}
      <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:14}}>
        <div style={{position:"relative",flexShrink:0}}>
          {shot&&!imgErr?(
            <div style={{width:58,height:58,borderRadius:12,overflow:"hidden",border:`2px solid ${BLUE}44`,background:"#0d1422"}}>
              <img src={shot} alt={player.name} style={{width:"100%",height:"100%",objectFit:"cover",objectPosition:"top center"}} onError={()=>setImgErr(true)}/>
            </div>
          ):(
            <div style={{width:58,height:58,borderRadius:12,background:`${BLUE}18`,border:`2px solid ${BLUE}33`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:26}}>👤</div>
          )}
          <div style={{position:"absolute",bottom:-4,right:-4,background:BLUE,borderRadius:6,padding:"1px 6px",fontSize:9,fontWeight:900,color:"#fff",border:"1.5px solid #060c1a"}}>{player.position}</div>
        </div>
        <div style={{flex:1,minWidth:0}}>
          <div style={{fontWeight:900,fontSize:15,color:"#f8fafc",marginBottom:2}}>{player.name}</div>
          <div style={{fontSize:11,color:"#3b82f6",marginBottom:6}}>{player.team}</div>
          <div style={{display:"flex",gap:6}}>
            {[{l:"PTS",v:player.recentPts,c:"#3b82f6"},{l:"REB",v:player.recentReb,c:"#22c55e"},{l:"AST",v:player.recentAst,c:"#a855f7"}].map(s=>(
              <div key={s.l} style={{background:s.c+"18",border:`1px solid ${s.c}33`,borderRadius:6,padding:"3px 8px",textAlign:"center"}}>
                <div style={{fontSize:14,fontWeight:900,color:s.c,fontFamily:"'DM Mono',monospace"}}>{s.v}</div>
                <div style={{fontSize:8,color:s.c+"99",fontWeight:700}}>{s.l}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Stat sections — each with its own color */}
      {Object.entries(byStatMap).map(([stat,props])=>{
        const sc=STAT_COLOR[stat]||STAT_COLOR.Points;
        return(
          <div key={stat} style={{background:sc.bg,border:`1px solid ${sc.border}`,borderRadius:10,padding:"10px 12px",marginBottom:8,boxShadow:`inset 0 0 20px ${sc.glow}`}}>
            <div style={{display:"flex",alignItems:"center",gap:6,marginBottom:8}}>
              <span style={{fontSize:9,fontWeight:800,color:sc.text,letterSpacing:"0.1em",textTransform:"uppercase"}}>{stat}</span>
              <div style={{flex:1,height:1,background:sc.border}}/>
            </div>
            <div style={{display:"flex",gap:8}}>
              {props.map((p,i)=>(
                <OddsBtn key={i} market={{...p,game:gameName}} onClick={onBannerOpen} statColor={sc}/>
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
};

// ─── Game Markets View ─────────────────────────────────────────────────────────
const MKTABS=["Moneyline","Spread","Total","1st Half","Team Totals","Player Props"];

const GameMarketsView=({game,league,onAddToSlip,bankroll,onBack,playerData,propsLoading,propsAge,onRefreshProps})=>{
  const [activeTab,setActiveTab]=useState("Moneyline");
  const [banner,setBanner]=useState(null);
  const [teamFilter,setTeamFilter]=useState("All");
  const [statFilter,setStatFilter]=useState("All");
  const [markets]=useState(()=>genMarkets(game,playerData));
  const lm=playerData?genMarkets(game,playerData):markets;
  const tms=Object.keys(game.teams);
  const gameName=`${game.teams[tms[0]].name} vs ${game.teams[tms[1]].name}`;
  const teamNames=tms.map(t=>game.teams[t].name);
  const allStats=["All","Points","Rebounds","Assists","PRA","3-Pointers","Blocks","Steals"];

  const renderMkts=()=>{
    const m=lm;
    const mBtn=(mk,i)=><OddsBtn key={i} market={{...mk,game:gameName}} onClick={setBanner}/>;
    if(activeTab==="Moneyline") return <div style={{display:"flex",gap:10}}>{m.moneyline.map(mBtn)}</div>;
    if(activeTab==="Spread")    return <div style={{display:"flex",gap:10}}>{m.spread.map(mBtn)}</div>;
    if(activeTab==="Total")     return <div style={{display:"flex",gap:10}}>{m.total.map(mBtn)}</div>;
    if(activeTab==="1st Half")  return <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>{m.firstHalf.map(mBtn)}</div>;
    if(activeTab==="Team Totals") return(
      <div>{teamNames.map(tn=>(
        <div key={tn} style={{marginBottom:14}}>
          <div style={{fontSize:11,color:"#4a5568",fontWeight:700,marginBottom:8,letterSpacing:"0.06em"}}>{tn.toUpperCase()}</div>
          <div style={{display:"flex",gap:8}}>{m.teamTotals.filter(mk=>mk.team===tn).map(mBtn)}</div>
        </div>
      ))}</div>
    );
    if(activeTab==="Player Props"){
      const pp=m.playerProps;
      if(propsLoading)return<div style={{textAlign:"center",padding:40,color:BLUE_LIGHT,animation:"pulse 1s infinite",fontSize:14,fontWeight:600}}>Loading player props...</div>;
      if(!pp.length)return(
        <div style={{textAlign:"center",padding:40}}>
          <div style={{fontSize:32,marginBottom:12}}>📊</div>
          <div style={{color:"#4a5568",fontSize:14,marginBottom:16}}>Props load when recent game stats are available.</div>
          <button onClick={onRefreshProps} style={{padding:"10px 24px",background:`${BLUE}22`,border:`1px solid ${BLUE}44`,borderRadius:8,color:BLUE_LIGHT,cursor:"pointer",fontSize:13,fontWeight:600}}>Retry</button>
        </div>
      );
      const filtered=pp.filter(p=>(teamFilter==="All"||p.team===teamFilter||p.teamAbbr===teamFilter)&&p.props.some(pr=>statFilter==="All"||pr.stat===statFilter));
      const filteredWithStat=filtered.map(p=>({...p,props:p.props.filter(pr=>statFilter==="All"||pr.stat===statFilter)})).filter(p=>p.props.length>0);
      return(
        <div>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:10,fontSize:11}}>
            <div style={{color:"#374151"}}>{propsAge?`Updated ${propsAge}`:"Recent game stats"}</div>
            <button onClick={onRefreshProps} style={{background:"transparent",border:`1px solid #1e2d45`,borderRadius:6,color:"#4a5568",padding:"3px 10px",cursor:"pointer",fontSize:11}}>↺ Refresh</button>
          </div>
          <div style={{display:"flex",gap:6,flexWrap:"wrap",marginBottom:8}}>
            {["All",...teamNames].map(t=>(
              <button key={t} onClick={()=>setTeamFilter(t)} style={{padding:"4px 12px",borderRadius:20,fontSize:11,fontWeight:600,border:teamFilter===t?`1px solid ${BLUE_LIGHT}`:"1px solid #1e2d45",background:teamFilter===t?`${BLUE}22`:"transparent",color:teamFilter===t?BLUE_LIGHT:"#4a5568",cursor:"pointer"}}>{t==="All"?"All Teams":t.split(" ").slice(-1)[0]}</button>
            ))}
          </div>
          <div style={{display:"flex",gap:6,flexWrap:"wrap",marginBottom:16}}>
            {allStats.map(s=>{
              const sc=STAT_COLOR[s];
              return <button key={s} onClick={()=>setStatFilter(s)} style={{padding:"4px 12px",borderRadius:20,fontSize:11,fontWeight:600,border:statFilter===s?`1px solid ${sc?.accent||BLUE_LIGHT}`:"1px solid #1e2d45",background:statFilter===s?`${sc?.accent||BLUE}22`:"transparent",color:statFilter===s?(sc?.text||BLUE_LIGHT):"#4a5568",cursor:"pointer"}}>{s}</button>;
            })}
          </div>
          {filteredWithStat.length===0&&<div style={{color:"#374151",textAlign:"center",padding:24}}>No props match this filter.</div>}
          {filteredWithStat.map(player=>(
            <PropPlayerCard key={player.name} player={player} gameName={gameName} onBannerOpen={setBanner}/>
          ))}
        </div>
      );
    }
    return null;
  };

  return(
    <div style={{paddingBottom:banner?360:0}}>
      {/* Header */}
      <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:16}}>
        <button onClick={onBack} style={{background:"transparent",border:`1px solid #1e2d45`,borderRadius:8,color:"#94a3b8",padding:"7px 14px",cursor:"pointer",fontSize:13}}>← Back</button>
        <div style={{display:"flex",alignItems:"center",gap:8,flex:1,minWidth:0}}>
          <TeamLogo abbr={tms[0]} size={26}/>
          <div style={{fontWeight:900,fontSize:14,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{gameName}</div>
          <TeamLogo abbr={tms[1]} size={26}/>
        </div>
        <a href={buildStreamUrl(game.teams[tms[0]].name,game.teams[tms[1]].name)} target="_blank" rel="noopener noreferrer" style={{textDecoration:"none",flexShrink:0}}>
          <div style={{padding:"6px 12px",background:`${BLUE}22`,border:`1px solid ${BLUE}44`,borderRadius:8,color:BLUE_LIGHT,fontSize:11,fontWeight:700}}>📺 Watch</div>
        </a>
      </div>

      {/* Win prob */}
      {game.win_probability&&(
        <div style={{background:"#080d1a",borderRadius:10,padding:"12px 14px",marginBottom:16,border:"1px solid #1e2d45"}}>
          {tms.map(t=><WinBar key={t} prob={game.win_probability[t]} team={game.teams[t].name} logo={TEAM_LOGOS[t]}/>)}
        </div>
      )}

      {/* Market tabs */}
      <div style={{display:"flex",gap:4,overflowX:"auto",marginBottom:14,paddingBottom:2}}>
        {MKTABS.map(tab=>(
          <button key={tab} onClick={()=>setActiveTab(tab)} style={{padding:"7px 13px",borderRadius:20,fontSize:12,fontWeight:600,border:activeTab===tab?`1px solid ${BLUE_LIGHT}`:"1px solid #1e2d45",background:activeTab===tab?`${BLUE}22`:"transparent",color:activeTab===tab?BLUE_LIGHT:"#4a5568",cursor:"pointer",whiteSpace:"nowrap",flexShrink:0}}>
            {tab}{tab==="Player Props"&&propsLoading?" ⏳":""}
          </button>
        ))}
      </div>
      <div style={{fontSize:10,color:"#1e2d45",marginBottom:10}}>Tap odds · compare all 8 books · best odds highlighted</div>
      {renderMkts()}
      {banner&&(
        <><div onClick={()=>setBanner(null)} style={{position:"fixed",inset:0,background:"#000000cc",zIndex:999}}/><OddsBanner market={banner} game={gameName} onClose={()=>setBanner(null)} onAddToSlip={b=>{onAddToSlip(b);setBanner(null);}} bankroll={bankroll}/></>
      )}
    </div>
  );
};

// ─── Games Tab ─────────────────────────────────────────────────────────────────
const CACHED_STATS = {
  "938a267b":{
    BOS:[{name:"Jayson Tatum",position:"F",stats:{points:16,rebounds:11,assists:2,three_points_made:2,blocks:0,steals:2}},{name:"Jaylen Brown",position:"G",stats:{points:29,rebounds:7,assists:4,three_points_made:2,blocks:0,steals:0}},{name:"Derrick White",position:"G",stats:{points:15,rebounds:6,assists:1,three_points_made:1,blocks:0,steals:3}},{name:"Payton Pritchard",position:"G",stats:{points:10,rebounds:1,assists:3,three_points_made:2,blocks:0,steals:1}},{name:"Al Horford",position:"C",stats:{points:4,rebounds:10,assists:1,three_points_made:0,blocks:2,steals:1}}],
    MIN:[{name:"Jaden McDaniels",position:"F",stats:{points:19,rebounds:6,assists:3,three_points_made:3,blocks:0,steals:0}},{name:"Bones Hyland",position:"G",stats:{points:23,rebounds:3,assists:3,three_points_made:3,blocks:0,steals:1}},{name:"Ayo Dosunmu",position:"G",stats:{points:17,rebounds:8,assists:6,three_points_made:2,blocks:2,steals:1}},{name:"Naz Reid",position:"C",stats:{points:11,rebounds:7,assists:0,three_points_made:1,blocks:1,steals:0}},{name:"Julius Randle",position:"F",stats:{points:9,rebounds:9,assists:4,three_points_made:1,blocks:0,steals:2}}],
  },
  "7927e749":{
    PHX:[{name:"Jalen Green",position:"F",stats:{points:20,rebounds:3,assists:7,three_points_made:2,blocks:1,steals:0}},{name:"Collin Gillespie",position:"G",stats:{points:16,rebounds:4,assists:3,three_points_made:4,blocks:0,steals:1}},{name:"Ryan Dunn",position:"F",stats:{points:12,rebounds:3,assists:2,three_points_made:2,blocks:1,steals:3}}],
    TOR:[{name:"Immanuel Quickley",position:"G",stats:{points:11,rebounds:3,assists:1,three_points_made:1,blocks:0,steals:2}},{name:"RJ Barrett",position:"G",stats:{points:13,rebounds:3,assists:3,three_points_made:1,blocks:0,steals:0}},{name:"Gradey Dick",position:"G",stats:{points:10,rebounds:3,assists:1,three_points_made:2,blocks:0,steals:1}},{name:"Ja'Kobe Walter",position:"G",stats:{points:13,rebounds:3,assists:1,three_points_made:3,blocks:0,steals:0}},{name:"Brandon Ingram",position:"F",stats:{points:6,rebounds:4,assists:1,three_points_made:0,blocks:3,steals:0}}],
  },
};
const TEAM_RECENT_GAME = { BOS:"938a267b",MIN:"938a267b",PHX:"7927e749",TOR:"7927e749" };
const REFRESH_MS = 90000;

const GamesTab=({nbaGames,ncaaGames,bankroll,bookOddsCache,onAddToSlip})=>{
  const [lt,setLt]=useState("nba");
  const [filter,setFilter]=useState("all");
  const [openId,setOpenId]=useState(null);
  const [pdCache,setPdCache]=useState({});
  const [pLoading,setPLoading]=useState({});
  const [pAge,setPAge]=useState({});
  const timers=useRef({});
  const allG=[...nbaGames,...ncaaGames];
  const openGame=openId?allG.find(g=>g.id===openId):null;

  const fetchProps=useCallback(async(game)=>{
    const tms=Object.keys(game.teams),[hk,ak]=tms;
    setPLoading(p=>({...p,[game.id]:true}));
    const rId=TEAM_RECENT_GAME[hk]||TEAM_RECENT_GAME[ak];
    if(rId){
      const cached=CACHED_STATS[rId.slice(0,8)];
      if(cached){
        const pd={};
        const keys=Object.keys(cached);
        if(cached[hk]){pd[hk]=cached[hk];pd[ak]=cached[ak]||[];}
        else{pd[hk]=cached[keys[0]]||[];pd[ak]=cached[keys[1]]||[];}
        setPdCache(p=>({...p,[game.id]:pd}));
        setPAge(p=>({...p,[game.id]:new Date().toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"})}));
      } else {
        // Generic fallback
        const mk=(abbr,n)=>[{name:`${n} Star Guard`,position:"G",stats:{points:22,rebounds:4,assists:6,three_points_made:3,blocks:0,steals:1}},{name:`${n} Star Forward`,position:"F",stats:{points:18,rebounds:7,assists:2,three_points_made:1,blocks:1,steals:1}},{name:`${n} Center`,position:"C",stats:{points:12,rebounds:10,assists:2,three_points_made:0,blocks:2,steals:0}}];
        const pd={};
        pd[hk]=mk(hk,game.teams[hk].name.split(" ").slice(-1)[0]);
        pd[ak]=mk(ak,game.teams[ak].name.split(" ").slice(-1)[0]);
        setPdCache(p=>({...p,[game.id]:pd}));
        setPAge(p=>({...p,[game.id]:new Date().toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"})}));
      }
    }
    setPLoading(p=>({...p,[game.id]:false}));
  },[]);

  const openGame2=useCallback((gameId)=>{
    setOpenId(gameId);
    const g=allG.find(x=>x.id===gameId);
    if(g&&!timers.current[gameId]){
      fetchProps(g);
      timers.current[gameId]=setInterval(()=>fetchProps(g),REFRESH_MS);
    }
  },[allG,fetchProps]);

  useEffect(()=>()=>Object.values(timers.current).forEach(clearInterval),[]);

  if(openGame)return <GameMarketsView game={openGame} league={openGame.league} onAddToSlip={onAddToSlip} bankroll={bankroll} onBack={()=>setOpenId(null)} playerData={pdCache[openGame.id]} propsLoading={!!pLoading[openGame.id]} propsAge={pAge[openGame.id]} onRefreshProps={()=>fetchProps(openGame)}/>;

  const games=lt==="nba"?nbaGames:ncaaGames;
  const lg=lt==="nba"?"NBA":"NCAAMB";
  const filtered=games.filter(g=>{
    if(filter==="upcoming")return g.status==="scheduled";
    if(filter==="value")return g.win_probability&&Object.keys(g.win_probability).some(t=>(g.win_probability[t]-(bookOddsCache[g.id]?.[t]||g.win_probability[t]))>4);
    return true;
  });

  return(
    <div>
      <div style={{display:"flex",gap:8,marginBottom:14}}>
        {["nba","ncaamb"].map(t=>(
          <button key={t} onClick={()=>setLt(t)} style={{flex:1,padding:"9px 0",borderRadius:8,border:lt===t?`1px solid ${BLUE_LIGHT}`:"1px solid #1e2d45",background:lt===t?`${BLUE}22`:"transparent",color:lt===t?BLUE_LIGHT:"#4a5568",fontWeight:700,fontSize:13,cursor:"pointer"}}>
            {t==="nba"?"🏀 NBA":"🎓 NCAA Men's"}
          </button>
        ))}
      </div>
      <div style={{display:"flex",gap:6,marginBottom:18}}>
        {[["all","All"],["upcoming","Upcoming"],["value","⚡ Value"]].map(([k,l])=>(
          <button key={k} onClick={()=>setFilter(k)} style={{padding:"6px 14px",borderRadius:20,fontSize:12,fontWeight:600,border:filter===k?`1px solid ${BLUE_LIGHT}`:"1px solid #1e2d45",background:filter===k?`${BLUE}22`:"transparent",color:filter===k?BLUE_LIGHT:"#4a5568",cursor:"pointer"}}>{l}</button>
        ))}
      </div>
      {filtered.map(game=>{
        const tms=Object.keys(game.teams),[hk,ak]=tms;
        const isClosed=game.status==="closed";
        const wp=game.win_probability;
        const hML=wp?toAmerican(wp[hk]):null;
        const aML=wp?toAmerican(wp[ak]):null;
        const total=220;
        return(
          <div key={game.id} style={{background:"linear-gradient(135deg,#060912,#080d1a)",border:`1px solid #1e2d45`,borderRadius:14,padding:16,marginBottom:12,boxShadow:!isClosed?`0 0 24px ${BLUE}08`:"none"}}>
            {/* Header */}
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:12}}>
              <div style={{display:"flex",gap:8}}>
                <Badge color={lg==="NBA"?BLUE_LIGHT:"#f59e0b"}>{lg}</Badge>
                {isClosed?<Badge color="#374151">FINAL</Badge>:<Badge color="#22c55e">UPCOMING</Badge>}
              </div>
              <span style={{fontSize:11,color:"#374151"}}>{game.local_start}</span>
            </div>
            {/* Teams with logos */}
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:12}}>
              <div style={{display:"flex",alignItems:"center",gap:10,flex:1}}>
                <TeamLogo abbr={hk} size={36}/>
                <div>
                  <div style={{fontSize:14,color:"#f8fafc",fontWeight:700}}>{game.teams[hk].name}</div>
                  {wp&&!isClosed&&<div style={{fontSize:10,color:"#374151"}}>{wp[hk].toFixed(1)}% to win</div>}
                  {isClosed&&<div style={{fontSize:26,fontWeight:900,color:"#fff",fontFamily:"monospace"}}>{game.score[hk]}</div>}
                </div>
              </div>
              <div style={{color:"#1e2d45",fontSize:16,fontWeight:900,padding:"0 10px"}}>vs</div>
              <div style={{display:"flex",alignItems:"center",gap:10,flex:1,justifyContent:"flex-end"}}>
                <div style={{textAlign:"right"}}>
                  <div style={{fontSize:14,color:"#f8fafc",fontWeight:700}}>{game.teams[ak].name}</div>
                  {wp&&!isClosed&&<div style={{fontSize:10,color:"#374151"}}>{wp[ak].toFixed(1)}% to win</div>}
                  {isClosed&&<div style={{fontSize:26,fontWeight:900,color:"#fff",fontFamily:"monospace"}}>{game.score[ak]}</div>}
                </div>
                <TeamLogo abbr={ak} size={36}/>
              </div>
            </div>
            {!isClosed&&(
              <>
                <a href={buildStreamUrl(game.teams[hk].name,game.teams[ak].name)} target="_blank" rel="noopener noreferrer" style={{textDecoration:"none",display:"block",marginBottom:8}}>
                  <div style={{padding:"7px 0",background:`${BLUE}15`,border:`1px solid ${BLUE}33`,borderRadius:8,color:BLUE_LIGHT,fontSize:12,fontWeight:700,textAlign:"center"}}>📺 Watch on streamed.su</div>
                </a>
                {wp&&(
                  <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:6,marginBottom:8}}>
                    {[
                      {label:game.teams[hk].name.split(" ").slice(-1)[0],odds:fmt(hML),pos:hML>0},
                      {label:`O/U ${total}`,odds:"-110",pos:false},
                      {label:game.teams[ak].name.split(" ").slice(-1)[0],odds:fmt(aML),pos:aML>0},
                    ].map((item,i)=>(
                      <button key={i} onClick={()=>openGame2(game.id)} style={{padding:"9px 6px",background:"#080d1a",border:`1px solid ${BLUE}22`,borderRadius:10,cursor:"pointer",textAlign:"center",transition:"border-color 0.15s"}}
                        onMouseEnter={e=>e.currentTarget.style.borderColor=BLUE+"88"}
                        onMouseLeave={e=>e.currentTarget.style.borderColor=BLUE+"22"}>
                        <div style={{fontSize:10,color:"#4a5568",marginBottom:3,fontWeight:600}}>{item.label}</div>
                        <div style={{fontSize:16,fontWeight:900,color:item.pos?"#22c55e":"#f8fafc",fontFamily:"monospace"}}>{item.odds}</div>
                      </button>
                    ))}
                  </div>
                )}
                <button onClick={()=>openGame2(game.id)} style={{width:"100%",padding:"10px 0",background:`linear-gradient(135deg,${BLUE}22,${BLUE_LIGHT}11)`,border:`1px solid ${BLUE}44`,borderRadius:10,color:BLUE_LIGHT,cursor:"pointer",fontSize:13,fontWeight:700}}>
                  View All Markets — Spreads · Totals · Props →
                </button>
              </>
            )}
          </div>
        );
      })}
    </div>
  );
};

// ─── Live Tab ──────────────────────────────────────────────────────────────────
const LiveTab=({liveGames,upcomingGames,bankroll,onAddToSlip})=>{
  const [liveBets,setLiveBets]=useState({});
  const [loadId,setLoadId]=useState(null);
  const [selected,setSelected]=useState(null);
  const urgC={"Act Now":"#ef4444","Monitor":"#f59e0b","Wait":BLUE_LIGHT};

  const getPicks=async(game)=>{
    if(liveBets[game.id]){setSelected(game.id);return;}
    setLoadId(game.id);setSelected(game.id);
    const tms=Object.keys(game.teams);
    const r=await callClaude(`Live NBA game. ${game.teams[tms[1]].name} @ ${game.teams[tms[0]].name}. Bankroll $${bankroll}.\n5 live bets JSON array:\n[{"type":"Game Total"|"Player Prop"|"Team Total"|"Live Spread"|"Live ML","pick":"...","odds":"...","reasoning":"...","confidence":"Low"|"Medium"|"High","risk":"Low"|"Medium"|"High","urgency":"Act Now"|"Monitor"|"Wait","suggestedStake":number}]`,1800);
    setLiveBets(p=>({...p,[game.id]:Array.isArray(r)?r:r?._error?[{_error:r._error}]:[]}));setLoadId(null);
  };

  if(!liveGames.length)return(
    <div>
      <div style={{background:"linear-gradient(135deg,#060912,#080d1a)",border:"1px solid #1e2d45",borderRadius:14,padding:28,textAlign:"center",marginBottom:20}}>
        <div style={{fontSize:48,marginBottom:14}}>🏀</div>
        <div style={{fontWeight:900,fontSize:20,marginBottom:8}}>No Games Live Right Now</div>
        <div style={{color:"#4a5568",fontSize:14,lineHeight:1.7,marginBottom:20}}>Live betting unlocks when games tip off.</div>
        <div style={{display:"inline-flex",alignItems:"center",gap:8,background:"#0d1422",borderRadius:8,padding:"8px 16px",fontSize:12,color:"#374151",border:"1px solid #1e2d45"}}>
          <span style={{display:"inline-block",width:8,height:8,borderRadius:"50%",background:"#1e2d45"}}/> OFFLINE · No active games
        </div>
      </div>
      {upcomingGames.slice(0,5).map(g=>{
        const tms=Object.keys(g.teams);
        return(
          <div key={g.id} style={{background:"#060912",border:"1px solid #1e2d45",borderRadius:10,padding:"12px 16px",marginBottom:8}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:8}}>
              <div style={{display:"flex",alignItems:"center",gap:8}}>
                <TeamLogo abbr={tms[0]} size={24}/>
                <div style={{fontSize:13,color:"#94a3b8",fontWeight:600}}>{g.teams[tms[0]].name} vs {g.teams[tms[1]].name}</div>
                <TeamLogo abbr={tms[1]} size={24}/>
              </div>
              <div style={{fontSize:11,color:"#374151"}}>{g.local_start?.split(", ").slice(1).join(", ").replace(" MST","")}</div>
            </div>
            <a href={buildStreamUrl(g.teams[tms[0]].name,g.teams[tms[1]].name)} target="_blank" rel="noopener noreferrer" style={{textDecoration:"none"}}>
              <div style={{padding:"6px 0",background:`${BLUE}15`,border:`1px solid ${BLUE}33`,borderRadius:6,color:BLUE_LIGHT,fontSize:11,fontWeight:700,textAlign:"center"}}>📺 Watch on streamed.su</div>
            </a>
          </div>
        );
      })}
    </div>
  );

  return(
    <div>
      <div style={{fontSize:11,color:"#ef4444",fontWeight:700,letterSpacing:"0.1em",marginBottom:14,display:"flex",alignItems:"center",gap:8}}>
        <span style={{display:"inline-block",width:8,height:8,borderRadius:"50%",background:"#ef4444",animation:"pulse 0.9s infinite"}}/>{liveGames.length} LIVE
      </div>
      {liveGames.map(game=>{
        const tms=Object.keys(game.teams),[hk,ak]=tms;
        const hs=game.score?.[hk]??"—",as_=game.score?.[ak]??"—";
        const isSel=selected===game.id;
        return(
          <div key={game.id} style={{marginBottom:14}}>
            <div style={{background:isSel?"linear-gradient(135deg,#050d1f,#060912)":"linear-gradient(135deg,#060912,#080d1a)",border:isSel?`1px solid ${BLUE}66`:"1px solid #1e2d45",borderRadius:12,padding:"14px 16px"}}>
              <div style={{display:"flex",gap:8,marginBottom:10}}><Badge color="#ef4444">LIVE</Badge><Badge color={BLUE_LIGHT}>{game.league}</Badge></div>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:10}}>
                <div style={{display:"flex",alignItems:"center",gap:8}}>
                  <TeamLogo abbr={ak} size={32}/>
                  <div>
                    <div style={{fontSize:13,color:as_>hs?"#fff":"#64748b",fontWeight:as_>hs?700:400}}>{game.teams[ak].name}</div>
                    <div style={{fontSize:13,color:hs>as_?"#fff":"#64748b",fontWeight:hs>as_?700:400,marginTop:3}}>{game.teams[hk].name}</div>
                  </div>
                  <TeamLogo abbr={hk} size={32}/>
                </div>
                <div style={{textAlign:"right"}}>
                  <div style={{fontSize:30,fontWeight:900,color:as_>hs?"#fff":"#374151",fontFamily:"monospace",lineHeight:1}}>{as_}</div>
                  <div style={{fontSize:30,fontWeight:900,color:hs>as_?"#fff":"#374151",fontFamily:"monospace",lineHeight:1,marginTop:2}}>{hs}</div>
                </div>
              </div>
              <div style={{display:"flex",gap:8}}>
                <a href={buildStreamUrl(game.teams[ak].name,game.teams[hk].name)} target="_blank" rel="noopener noreferrer" style={{textDecoration:"none",flex:1}}>
                  <div style={{padding:"7px 0",background:`${BLUE}15`,border:`1px solid ${BLUE}33`,borderRadius:8,color:BLUE_LIGHT,fontSize:12,fontWeight:700,textAlign:"center"}}>📺 Watch</div>
                </a>
                <button onClick={()=>getPicks(game)} style={{flex:1,padding:"7px 0",background:"transparent",border:`1px solid ${BLUE}44`,borderRadius:8,color:BLUE_LIGHT,cursor:"pointer",fontSize:12,fontWeight:600}}>
                  {loadId===game.id?"⏳ Loading...":"⚡ Live AI Picks"}
                </button>
              </div>
            </div>
            {isSel&&liveBets[game.id]?.map((bet,i)=>(
              bet._error ? (
                <div key={i} style={{background:"#1a0508",border:"1px solid #7f1d1d",borderRadius:10,padding:14,marginTop:8,textAlign:"center"}}>
                  <div style={{fontSize:22,marginBottom:8}}>⚠️</div>
                  <div style={{color:"#fca5a5",fontSize:13,fontWeight:600,marginBottom:4}}>Couldn't load AI picks</div>
                  <div style={{color:"#ef444488",fontSize:11}}>{bet._error}</div>
                </div>
              ) : (
              <div key={i} style={{background:"linear-gradient(135deg,#060912,#080d1a)",border:`1px solid #1e2d45`,borderRadius:10,padding:14,marginTop:8}}>
                <div style={{display:"flex",justifyContent:"space-between",marginBottom:8}}>
                  <div style={{display:"flex",gap:6,flexWrap:"wrap"}}>
                    <Badge color={bet.risk==="Low"?"#22c55e":bet.risk==="High"?"#ef4444":"#f59e0b"}>{bet.risk} risk</Badge>
                    <Badge color={BLUE_LIGHT}>{bet.type}</Badge>
                    {bet.urgency&&<span style={{background:urgC[bet.urgency]+"22",color:urgC[bet.urgency],border:`1px solid ${urgC[bet.urgency]}44`,borderRadius:4,padding:"2px 8px",fontSize:11,fontWeight:700,animation:bet.urgency==="Act Now"?"pulse 0.8s infinite":"none"}}>{bet.urgency==="Act Now"?"🔴":"🟡"} {bet.urgency}</span>}
                  </div>
                  <div style={{fontSize:18,fontWeight:900,color:"#22c55e",fontFamily:"monospace"}}>${bet.suggestedStake||25}</div>
                </div>
                <div style={{background:`${BLUE}15`,borderRadius:8,padding:"9px 12px",borderLeft:`3px solid ${BLUE_LIGHT}`,marginBottom:8}}>
                  <div style={{fontSize:10,color:BLUE_LIGHT,fontWeight:700,marginBottom:2}}>LIVE BET</div>
                  <div style={{fontSize:14,fontWeight:900,color:"#fff"}}>{bet.pick}</div>
                  {bet.odds&&<div style={{fontSize:11,color:"#94a3b8",marginTop:2}}>{bet.odds}</div>}
                </div>
                <p style={{color:"#64748b",fontSize:12,lineHeight:1.6,margin:"0 0 10px"}}>{bet.reasoning}</p>
                <button onClick={()=>onAddToSlip({id:`live-${game.id}-${i}`,pick:bet.pick,betType:bet.type,odds:bet.odds||"-110",risk:bet.risk,suggestedStake:bet.suggestedStake||25,game:`${game.teams[ak].name} @ ${game.teams[hk].name} (LIVE)`,bookId:"fanduel",bookName:"FanDuel",source:"live"})}
                  style={{width:"100%",padding:"8px 0",background:`${BLUE}22`,border:`1px solid ${BLUE}44`,borderRadius:8,color:BLUE_LIGHT,cursor:"pointer",fontSize:12,fontWeight:700}}>
                  + Add to Bet Slip
                </button>
              </div>
              )
            ))}
          </div>
        );
      })}
    </div>
  );
};

// ─── Best Bets Tab ─────────────────────────────────────────────────────────────
const riskCol={Low:"#22c55e",Medium:"#f59e0b",High:"#ef4444"};
const riskBg ={Low:"#022a10",Medium:"#1a1000",High:"#1a0508"};

const VALUE_FACTOR_ICONS = {
  "pace":"⚡","total":"🎯","spread":"📐","rest":"😴","back-to-back":"📅","home":"🏠","away":"✈️",
  "public":"📢","line":"📊","injury":"🩹","revenge":"🔥","fatigue":"😓","matchup":"🆚",
  "default":"💡",
};
const factorIcon = (f) => {
  const fl = f.toLowerCase();
  for(const [key,icon] of Object.entries(VALUE_FACTOR_ICONS)){
    if(fl.includes(key)) return icon;
  }
  return VALUE_FACTOR_ICONS.default;
};

const BestBetsTab=({allGames,bankroll,onAddToSlip})=>{
  const [bets,setBets]=useState([]);
  const [loading,setLoading]=useState(false);
  const [fetched,setFetched]=useState(false);
  const [rf,setRf]=useState("All");
  const [expanded,setExpanded]=useState({});
  const [apiError,setApiError]=useState(null);

  const load = async () => {
    setLoading(true); setFetched(true); setApiError(null);
    const result = await fetchBestBets(allGames, bankroll);
    if (result?._error) {
      setApiError(result._error);
      setBets([]);
    } else if (Array.isArray(result) && result.length > 0) {
      setBets(result);
    } else {
      // Shouldn't happen since fetchBestBets now always falls back, but just in case
      setApiError("No picks returned. Please retry.");
      setBets([]);
    }
    setLoading(false);
  };
  const filtered=rf==="All"?bets:bets.filter(b=>b.risk===rf);
  const toggleExpand=(i)=>setExpanded(p=>({...p,[i]:!p[i]}));

  if(!fetched)return(
    <div style={{textAlign:"center",padding:"40px 20px"}}>
      <div style={{fontSize:52,marginBottom:16}}>🎯</div>
      <h2 style={{fontSize:22,fontWeight:900,marginBottom:8,color:"#f8fafc"}}>AI Best Bets Engine</h2>
      <p style={{color:"#4a5568",fontSize:14,marginBottom:12,lineHeight:1.7,maxWidth:340,margin:"0 auto 24px"}}>
        Deep analysis on every game — value factors, score projections, prop picks, matchup edges, and the risks.
      </p>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:8,marginBottom:28,maxWidth:360,margin:"0 auto 28px"}}>
        {[["📊","Score projections"],["💡","Value factors"],["🎭","Prop picks"],["⚠️","Risk flags"],["🆚","Matchup edges"],["📈","EV analysis"]].map(([icon,label])=>(
          <div key={label} style={{background:"#080d1a",border:"1px solid #1e2d45",borderRadius:10,padding:"10px 8px",textAlign:"center"}}>
            <div style={{fontSize:20,marginBottom:4}}>{icon}</div>
            <div style={{fontSize:9,color:"#4a5568",fontWeight:700,lineHeight:1.4}}>{label.toUpperCase()}</div>
          </div>
        ))}
      </div>
      <button onClick={load} style={{padding:"14px 44px",background:`linear-gradient(135deg,${BLUE},${BLUE_LIGHT})`,border:"none",borderRadius:12,color:"#fff",fontSize:15,fontWeight:900,cursor:"pointer",boxShadow:`0 6px 28px ${BLUE_GLOW}`}}>
        🔍 Generate Best Bets
      </button>
    </div>
  );

  if(loading)return(
    <div style={{textAlign:"center",padding:60}}>
      <div style={{fontSize:40,marginBottom:16,animation:"pulse 0.8s infinite"}}>🤖</div>
      <div style={{color:BLUE_LIGHT,fontSize:15,fontWeight:700,marginBottom:8}}>Analyzing every game...</div>
      <div style={{color:"#374151",fontSize:12}}>Checking pace, spreads, rest, matchups, public money & more</div>
    </div>
  );

  if(apiError)return(
    <div style={{textAlign:"center",padding:"32px 20px"}}>
      <div style={{fontSize:40,marginBottom:14}}>⚠️</div>
      <div style={{fontWeight:800,fontSize:16,color:"#f8fafc",marginBottom:12}}>Couldn't generate picks</div>
      <div style={{background:"#1a0508",border:"1px solid #7f1d1d",borderRadius:10,padding:"12px 16px",marginBottom:20,fontSize:12,color:"#fca5a5",textAlign:"left",maxWidth:420,margin:"0 auto 20px"}}>
        <strong>Error:</strong> {apiError}
      </div>
      <div style={{color:"#4a5568",fontSize:12,marginBottom:20,lineHeight:1.8,maxWidth:360,margin:"0 auto 20px"}}>
        The AI picks engine runs via the Anthropic API.<br/>
        If you're seeing this inside a Claude.ai artifact,<br/>
        the API connection should be active — tap retry.
      </div>
      <button onClick={()=>{setFetched(false);setApiError(null);}} style={{padding:"12px 32px",background:`linear-gradient(135deg,${BLUE},${BLUE_LIGHT})`,border:"none",borderRadius:10,color:"#fff",cursor:"pointer",fontSize:13,fontWeight:700,boxShadow:`0 4px 16px ${BLUE_GLOW}`}}>
        ↺ Retry
      </button>
    </div>
  );

  return(
    <div>
      {/* Filter row */}
      <div style={{display:"flex",gap:6,marginBottom:18,flexWrap:"wrap",alignItems:"center"}}>
        {["All","Low","Medium","High"].map(r=>(
          <button key={r} onClick={()=>setRf(r)} style={{padding:"5px 14px",borderRadius:20,fontSize:12,fontWeight:600,border:rf===r?`1px solid ${riskCol[r]||BLUE_LIGHT}`:"1px solid #1e2d45",background:rf===r?(riskCol[r]||BLUE)+"22":"transparent",color:rf===r?(riskCol[r]||BLUE_LIGHT):"#4a5568",cursor:"pointer"}}>
            {r==="All"?"All Bets":`${r==="Low"?"🟢":r==="Medium"?"🟡":"🔴"} ${r}`}
          </button>
        ))}
        <button onClick={()=>{setFetched(false);setBets([]);setExpanded({});}} style={{marginLeft:"auto",padding:"5px 14px",borderRadius:20,fontSize:12,background:"transparent",border:"1px solid #1e2d45",color:"#4a5568",cursor:"pointer"}}>↺ Reset</button>
      </div>

      {filtered.length===0&&<div style={{textAlign:"center",color:"#374151",padding:40}}>No bets found.</div>}

      {filtered.map((bet,i)=>{
        const rc=riskCol[bet.risk]||BLUE_LIGHT;
        const rb=riskBg[bet.risk]||"#060912";
        const cc=bet.confidence==="High"?"#22c55e":bet.confidence==="Medium"?"#f59e0b":"#ef4444";
        const isOpen=!!expanded[i];

        return(
          <div key={i} style={{background:`linear-gradient(135deg,${rb},#060912)`,border:`1.5px solid ${rc}33`,borderRadius:14,marginBottom:16,overflow:"hidden",boxShadow:`0 0 24px ${rc}0a`}}>

            {/* ── Top section: always visible ── */}
            <div style={{padding:"16px 16px 0"}}>
              {/* Badges row */}
              <div style={{display:"flex",gap:6,marginBottom:10,flexWrap:"wrap",alignItems:"center"}}>
                <span style={{background:rc+"22",color:rc,border:`1px solid ${rc}44`,borderRadius:6,padding:"3px 10px",fontSize:11,fontWeight:800}}>
                  {bet.risk==="Low"?"🟢":bet.risk==="Medium"?"🟡":"🔴"} {bet.risk} Risk
                </span>
                <Badge color={BLUE_LIGHT}>{bet.betType}</Badge>
                <Badge color={cc}>{bet.confidence} conf.</Badge>
                {bet.expectedValue&&<Badge color="#22c55e">{bet.expectedValue}</Badge>}
                <div style={{marginLeft:"auto",textAlign:"right"}}>
                  <div style={{fontSize:9,color:"#374151",marginBottom:1}}>STAKE</div>
                  <div style={{fontSize:20,fontWeight:900,color:"#22c55e",fontFamily:"monospace"}}>${typeof bet.suggestedStake==="number"?bet.suggestedStake:parseInt(bet.suggestedStake)||25}</div>
                </div>
              </div>

              {/* Game */}
              <div style={{fontSize:11,color:"#4a5568",marginBottom:8}}>{bet.game}</div>

              {/* Pick highlight */}
              <div style={{background:`${BLUE}18`,borderRadius:10,padding:"12px 14px",borderLeft:`3px solid ${BLUE_LIGHT}`,marginBottom:12}}>
                <div style={{fontSize:10,color:BLUE_LIGHT,fontWeight:700,marginBottom:4,letterSpacing:"0.08em"}}>THE PLAY</div>
                <div style={{fontSize:16,fontWeight:900,color:"#fff"}}>{bet.pick}</div>
              </div>

              {/* Core reasoning */}
              <p style={{color:"#94a3b8",fontSize:13,lineHeight:1.7,margin:"0 0 12px"}}>{bet.reasoning}</p>
            </div>

            {/* ── Score projection + prop pick (always visible) ── */}
            {(bet.scoreProjection||bet.propPick)&&(
              <div style={{display:"grid",gridTemplateColumns:bet.scoreProjection&&bet.propPick?"1fr 1fr":"1fr",gap:8,padding:"0 16px 12px"}}>
                {bet.scoreProjection&&(
                  <div style={{background:"#030712",border:"1px solid #1e2d45",borderRadius:10,padding:"10px 12px"}}>
                    <div style={{fontSize:9,color:"#3b82f6",fontWeight:800,letterSpacing:"0.08em",marginBottom:5}}>📊 PROJECTION</div>
                    <div style={{fontSize:13,fontWeight:700,color:"#f8fafc",lineHeight:1.4}}>{bet.scoreProjection}</div>
                  </div>
                )}
                {bet.propPick&&(
                  <div style={{background:"#030712",border:`1px solid ${STAT_COLOR.Points.border}`,borderRadius:10,padding:"10px 12px"}}>
                    <div style={{fontSize:9,color:STAT_COLOR.Points.accent,fontWeight:800,letterSpacing:"0.08em",marginBottom:5}}>🎯 PROP I LIKE</div>
                    <div style={{fontSize:12,fontWeight:700,color:"#f8fafc",lineHeight:1.5}}>{bet.propPick}</div>
                  </div>
                )}
              </div>
            )}

            {/* ── Expand/collapse toggle ── */}
            <button onClick={()=>toggleExpand(i)} style={{width:"100%",background:"transparent",border:"none",borderTop:"1px solid #1e2d45",padding:"9px 16px",color:"#374151",fontSize:11,fontWeight:600,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",gap:6}}>
              {isOpen?"▲ Hide full analysis":"▼ Show value factors, matchup & risk"}
            </button>

            {/* ── Expanded deep analysis ── */}
            {isOpen&&(
              <div style={{padding:"0 16px 16px",borderTop:"none"}}>

                {/* Value factors */}
                {bet.valueFactors?.length>0&&(
                  <div style={{marginBottom:14}}>
                    <div style={{fontSize:10,color:"#4a5568",fontWeight:800,letterSpacing:"0.08em",marginBottom:8}}>💡 WHY THIS HAS VALUE</div>
                    <div style={{display:"flex",flexDirection:"column",gap:6}}>
                      {bet.valueFactors.map((f,j)=>(
                        <div key={j} style={{display:"flex",alignItems:"flex-start",gap:8,background:"#030712",borderRadius:8,padding:"8px 10px",border:"1px solid #1e2d45"}}>
                          <span style={{fontSize:16,flexShrink:0,lineHeight:1}}>{factorIcon(f)}</span>
                          <span style={{fontSize:12,color:"#94a3b8",lineHeight:1.5}}>{f}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Key matchup factor */}
                {bet.keyMatchup&&(
                  <div style={{background:"#030712",border:`1px solid ${rc}33`,borderRadius:10,padding:"10px 12px",marginBottom:12}}>
                    <div style={{fontSize:9,color:rc,fontWeight:800,letterSpacing:"0.08em",marginBottom:4}}>🆚 KEY MATCHUP FACTOR</div>
                    <div style={{fontSize:13,color:"#f8fafc",lineHeight:1.5}}>{bet.keyMatchup}</div>
                  </div>
                )}

                {/* Main risk */}
                {bet.mainRisk&&(
                  <div style={{background:"#1a0508",border:"1px solid #7f1d1d",borderRadius:10,padding:"10px 12px",marginBottom:14}}>
                    <div style={{fontSize:9,color:"#f87171",fontWeight:800,letterSpacing:"0.08em",marginBottom:4}}>⚠️ MAIN RISK</div>
                    <div style={{fontSize:12,color:"#fca5a5",lineHeight:1.5}}>{bet.mainRisk}</div>
                  </div>
                )}

                {/* Confidence meter */}
                <div style={{marginBottom:14}}>
                  <div style={{display:"flex",justifyContent:"space-between",fontSize:10,color:"#374151",marginBottom:4}}>
                    <span>CONFIDENCE</span><span style={{color:cc}}>{bet.confidence?.toUpperCase()}</span>
                  </div>
                  <div style={{height:5,background:"#0d1422",borderRadius:3}}>
                    <div style={{height:"100%",borderRadius:3,width:bet.confidence==="High"?"88%":bet.confidence==="Medium"?"55%":"28%",background:`linear-gradient(90deg,${BLUE},${cc})`,transition:"width 0.5s"}}/>
                  </div>
                </div>
              </div>
            )}

            {/* ── Add to slip ── */}
            <div style={{padding:"0 16px 16px"}}>
              <button onClick={()=>onAddToSlip({id:`best-${i}-${Date.now()}`,pick:bet.pick,betType:bet.betType,odds:"-110",risk:bet.risk,suggestedStake:typeof bet.suggestedStake==="number"?bet.suggestedStake:parseInt(bet.suggestedStake)||25,game:bet.game,bookId:"fanduel",bookName:"FanDuel",source:"bestbets"})}
                style={{width:"100%",padding:"10px 0",background:`${BLUE}22`,border:`1px solid ${BLUE}44`,borderRadius:9,color:BLUE_LIGHT,cursor:"pointer",fontSize:13,fontWeight:700}}>
                + Add to Bet Slip
              </button>
            </div>
          </div>
        );
      })}

      <div style={{textAlign:"center",marginTop:8}}>
        <button onClick={load} style={{padding:"10px 28px",background:"transparent",border:`1px solid #1e2d45`,borderRadius:8,color:BLUE_LIGHT,cursor:"pointer",fontSize:13,fontWeight:600}}>🔄 Regenerate</button>
      </div>
    </div>
  );
};

// ─── AZ Books Tab ──────────────────────────────────────────────────────────────
const BooksTab=()=>{
  const [hov,setHov]=useState(null);
  return(
    <div>
      <div style={{background:"linear-gradient(135deg,#050d1f,#060912)",border:`1px solid ${BLUE}33`,borderRadius:12,padding:"16px 18px",marginBottom:20}}>
        <div style={{display:"flex",gap:10,alignItems:"center",marginBottom:10}}>
          <span style={{fontSize:28}}>🌵</span>
          <div><div style={{fontWeight:900,fontSize:17}}>Arizona Legal Sportsbooks</div><div style={{fontSize:12,color:"#374151",marginTop:2}}>All licensed under ARS § 5-1301. Legal in AZ since 2021.</div></div>
        </div>
        <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
          <Badge color="#22c55e">✓ State Licensed</Badge><Badge color={BLUE_LIGHT}>✓ Legal Since 2021</Badge><Badge color="#f59e0b">✓ Must Be 21+</Badge>
        </div>
      </div>
      {BOOKS.map((b,i)=>(
        <a key={b.id} href={b.url} target="_blank" rel="noopener noreferrer" onMouseEnter={()=>setHov(i)} onMouseLeave={()=>setHov(null)} style={{textDecoration:"none",display:"block",marginBottom:10}}>
          <div style={{background:hov===i?"#080d1a":"linear-gradient(135deg,#060912,#080d1a)",border:hov===i?`1px solid ${b.color}66`:"1px solid #1e2d45",borderRadius:12,padding:"14px 18px",transition:"all 0.2s",boxShadow:hov===i?`0 4px 24px ${b.color}33`:"none",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
            <div style={{display:"flex",gap:12,alignItems:"center"}}>
              <div style={{width:36,height:36,borderRadius:8,background:b.color,display:"flex",alignItems:"center",justifyContent:"center",fontSize:13,fontWeight:900,color:"#fff"}}>{b.logo}</div>
              <div><div style={{fontWeight:800,fontSize:15,marginBottom:2}}>{b.name}</div><div style={{fontSize:11,color:"#374151"}}>Tap to open →</div></div>
            </div>
            <div style={{padding:"8px 16px",borderRadius:8,fontSize:12,fontWeight:700,background:`${b.color}22`,color:b.color,border:`1px solid ${b.color}44`}}>Open →</div>
          </div>
        </a>
      ))}
      <div style={{background:"#060912",border:"1px solid #1e2d45",borderRadius:8,padding:"12px 16px",marginTop:8,fontSize:11,color:"#374151",lineHeight:1.7}}>
        ⚠️ 21+ and physically in Arizona. Help: <strong style={{color:"#ef4444"}}>1-800-NEXT-STEP</strong>
      </div>
    </div>
  );
};

// ─── Main App ──────────────────────────────────────────────────────────────────
export default function App(){
  const [mainTab,setMainTab]=useState("live");
  const [bankroll,setBankroll]=useState(1000);
  const [nbaGames,setNbaGames]=useState([]);
  const [ncaaGames,setNcaaGames]=useState([]);
  const [liveGames,setLiveGames]=useState([]);
  const [betSlip,setBetSlip]=useState([]);
  const [carts,setCarts]=useState({});
  const [history,setHistory]=useState([]);
  const [bookOddsCache]=useState({});

  useEffect(()=>{
    const nba=[
      {id:"14a9a4b2",status:"scheduled",local_start:"Mon Mar 23, 4:00 PM",league:"NBA",home:"PHI",away:"OKC",teams:{PHI:{name:"Philadelphia 76ers"},OKC:{name:"Oklahoma City Thunder"}},win_probability:{PHI:9.3,OKC:90.7}},
      {id:"3dd482f4",status:"scheduled",local_start:"Mon Mar 23, 4:00 PM",league:"NBA",home:"DET",away:"LAL",teams:{DET:{name:"Detroit Pistons"},LAL:{name:"Los Angeles Lakers"}},win_probability:{DET:44.9,LAL:55.1}},
      {id:"51079268",status:"scheduled",local_start:"Mon Mar 23, 4:00 PM",league:"NBA",home:"MIA",away:"SAS",teams:{MIA:{name:"Miami Heat"},SAS:{name:"San Antonio Spurs"}},win_probability:{MIA:34.6,SAS:65.4}},
      {id:"6feaa83d",status:"scheduled",local_start:"Mon Mar 23, 4:00 PM",league:"NBA",home:"ORL",away:"IND",teams:{ORL:{name:"Orlando Magic"},IND:{name:"Indiana Pacers"}},win_probability:{ORL:87.1,IND:12.9}},
      {id:"0360d8e2",status:"scheduled",local_start:"Mon Mar 23, 4:30 PM",league:"NBA",home:"ATL",away:"MEM",teams:{ATL:{name:"Atlanta Hawks"},MEM:{name:"Memphis Grizzlies"}},win_probability:{ATL:88.2,MEM:11.8}},
      {id:"c396d089",status:"scheduled",local_start:"Mon Mar 23, 5:00 PM",league:"NBA",home:"CHI",away:"HOU",teams:{CHI:{name:"Chicago Bulls"},HOU:{name:"Houston Rockets"}},win_probability:{CHI:24.1,HOU:75.9}},
      {id:"c48dc12e",status:"scheduled",local_start:"Mon Mar 23, 6:00 PM",league:"NBA",home:"UTA",away:"TOR",teams:{UTA:{name:"Utah Jazz"},TOR:{name:"Toronto Raptors"}},win_probability:{UTA:13.4,TOR:86.6}},
      {id:"2d7f5b1e",status:"scheduled",local_start:"Mon Mar 23, 6:30 PM",league:"NBA",home:"DAL",away:"GSW",teams:{DAL:{name:"Dallas Mavericks"},GSW:{name:"Golden State Warriors"}},win_probability:{DAL:46.1,GSW:53.9}},
      {id:"ea923ca1",status:"scheduled",local_start:"Mon Mar 23, 7:00 PM",league:"NBA",home:"POR",away:"BKN",teams:{POR:{name:"Portland Trail Blazers"},BKN:{name:"Brooklyn Nets"}},win_probability:{POR:89.4,BKN:10.6}},
      {id:"4c4bf92c",status:"scheduled",local_start:"Mon Mar 23, 7:30 PM",league:"NBA",home:"LAC",away:"MIL",teams:{LAC:{name:"Los Angeles Clippers"},MIL:{name:"Milwaukee Bucks"}},win_probability:{LAC:86.5,MIL:13.5}},
      {id:"938a267b",status:"closed",local_start:"Sun Mar 22",league:"NBA",home:"BOS",away:"MIN",teams:{BOS:{name:"Boston Celtics"},MIN:{name:"Minnesota Timberwolves"}},score:{BOS:92,MIN:102}},
      {id:"ca15ef07",status:"closed",local_start:"Sun Mar 22",league:"NBA",home:"NYK",away:"WAS",teams:{NYK:{name:"New York Knicks"},WAS:{name:"Washington Wizards"}},score:{NYK:145,WAS:113}},
    ];
    const ncaa=[
      // ── Upcoming – with win probabilities ──────────────────────────────
      {id:"94914cc5",status:"scheduled",local_start:"Tue Mar 24, 4:00 PM",league:"NCAAMB",home:"TLSA",away:"WICH",
        teams:{TLSA:{name:"Tulsa Golden Hurricane"},WICH:{name:"Wichita State Shockers"}},
        win_probability:{TLSA:42.0,WICH:58.0}},
      {id:"24f835de",status:"scheduled",local_start:"Tue Mar 24, 6:00 PM",league:"NCAAMB",home:"UNM",away:"JOES",
        teams:{UNM:{name:"New Mexico Lobos"},JOES:{name:"Saint Joseph's Hawks"}},
        win_probability:{UNM:61.0,JOES:39.0}},
      {id:"ded914c3",status:"scheduled",local_start:"Wed Mar 25, 4:00 PM",league:"NCAAMB",home:"DAY",away:"ILST",
        teams:{DAY:{name:"Dayton Flyers"},ILST:{name:"Illinois State Redbirds"}},
        win_probability:{DAY:67.0,ILST:33.0}},
      {id:"c3537dbf",status:"scheduled",local_start:"Wed Mar 25, 6:00 PM",league:"NCAAMB",home:"AUB",away:"NEV",
        teams:{AUB:{name:"Auburn Tigers"},NEV:{name:"Nevada Wolf Pack"}},
        win_probability:{AUB:78.0,NEV:22.0}},
      {id:"68588e17",status:"scheduled",local_start:"Thu Mar 26, 4:10 PM",league:"NCAAMB",home:"PUR",away:"TEX",
        teams:{PUR:{name:"Purdue Boilermakers"},TEX:{name:"Texas Longhorns"}},
        win_probability:{PUR:55.0,TEX:45.0}},
      {id:"a6b81092",status:"scheduled",local_start:"Thu Mar 26, 4:30 PM",league:"NCAAMB",home:"NEB",away:"IOWA",
        teams:{NEB:{name:"Nebraska Cornhuskers"},IOWA:{name:"Iowa Hawkeyes"}},
        win_probability:{NEB:38.0,IOWA:62.0}},
      {id:"ba2848a3",status:"scheduled",local_start:"Thu Mar 26, 6:45 PM",league:"NCAAMB",home:"ARIZ",away:"ARK",
        teams:{ARIZ:{name:"Arizona Wildcats"},ARK:{name:"Arkansas Razorbacks"}},
        win_probability:{ARIZ:64.0,ARK:36.0}},
      {id:"9cb4a14c",status:"scheduled",local_start:"Thu Mar 26, 7:05 PM",league:"NCAAMB",home:"HOU",away:"ILL",
        teams:{HOU:{name:"Houston Cougars"},ILL:{name:"Illinois Fighting Illini"}},
        win_probability:{HOU:57.0,ILL:43.0}},
      {id:"7c35aedb",status:"scheduled",local_start:"Fri Mar 27, 4:10 PM",league:"NCAAMB",home:"DUKE",away:"SJU",
        teams:{DUKE:{name:"Duke Blue Devils"},SJU:{name:"St. John's Red Storm"}},
        win_probability:{DUKE:72.0,SJU:28.0}},
      {id:"03ba5a10",status:"scheduled",local_start:"Fri Mar 27, 4:35 PM",league:"NCAAMB",home:"MICH",away:"ALA",
        teams:{MICH:{name:"Michigan Wolverines"},ALA:{name:"Alabama Crimson Tide"}},
        win_probability:{MICH:44.0,ALA:56.0}},
      {id:"8d6f6d26",status:"scheduled",local_start:"Fri Mar 27, 6:45 PM",league:"NCAAMB",home:"CONN",away:"MSU",
        teams:{CONN:{name:"UConn Huskies"},MSU:{name:"Michigan State Spartans"}},
        win_probability:{CONN:60.0,MSU:40.0}},
      {id:"bb4f40be",status:"scheduled",local_start:"Fri Mar 27, 7:10 PM",league:"NCAAMB",home:"ISU",away:"TENN",
        teams:{ISU:{name:"Iowa State Cyclones"},TENN:{name:"Tennessee Volunteers"}},
        win_probability:{ISU:48.0,TENN:52.0}},
      // ── Recent results ─────────────────────────────────────────────────
      {id:"e1471a31",status:"closed",local_start:"Sun Mar 22",league:"NCAAMB",home:"PUR",away:"MIA",
        teams:{PUR:{name:"Purdue Boilermakers"},MIA:{name:"Miami (FL) Hurricanes"}},score:{PUR:79,MIA:69}},
      {id:"2b912246",status:"closed",local_start:"Sun Mar 22",league:"NCAAMB",home:"ISU",away:"UK",
        teams:{ISU:{name:"Iowa State Cyclones"},UK:{name:"Kentucky Wildcats"}},score:{ISU:82,UK:63}},
      {id:"617132a7",status:"closed",local_start:"Sun Mar 22",league:"NCAAMB",home:"KU",away:"SJU",
        teams:{KU:{name:"Kansas Jayhawks"},SJU:{name:"St. John's Red Storm"}},score:{KU:65,SJU:67}},
      {id:"01c3bb08",status:"closed",local_start:"Sun Mar 22",league:"NCAAMB",home:"UVA",away:"TENN",
        teams:{UVA:{name:"Virginia Cavaliers"},TENN:{name:"Tennessee Volunteers"}},score:{UVA:72,TENN:79}},
      {id:"2c9026cb",status:"closed",local_start:"Sun Mar 22",league:"NCAAMB",home:"AUB",away:"SEA",
        teams:{AUB:{name:"Auburn Tigers"},SEA:{name:"Seattle Redhawks"}},score:{AUB:91,SEA:85}},
      {id:"ffcc9908",status:"closed",local_start:"Sun Mar 22",league:"NCAAMB",home:"FLA",away:"IOWA",
        teams:{FLA:{name:"Florida Gators"},IOWA:{name:"Iowa Hawkeyes"}},score:{FLA:72,IOWA:73}},
      {id:"71d3c83b",status:"closed",local_start:"Sun Mar 22",league:"NCAAMB",home:"ARIZ",away:"USU",
        teams:{ARIZ:{name:"Arizona Wildcats"},USU:{name:"Utah State Aggies"}},score:{ARIZ:78,USU:66}},
      {id:"1fb1be4e",status:"closed",local_start:"Sun Mar 22",league:"NCAAMB",home:"CONN",away:"UCLA",
        teams:{CONN:{name:"UConn Huskies"},UCLA:{name:"UCLA Bruins"}},score:{CONN:73,UCLA:57}},
      {id:"f32c78ca",status:"closed",local_start:"Sun Mar 22",league:"NCAAMB",home:"ALA",away:"TTU",
        teams:{ALA:{name:"Alabama Crimson Tide"},TTU:{name:"Texas Tech Red Raiders"}},score:{ALA:90,TTU:65}},
    ];
    nba.forEach(g=>{if(g.win_probability){bookOddsCache[g.id]={};Object.keys(g.win_probability).forEach(t=>{bookOddsCache[g.id][t]=bkOffset(g.win_probability[t]);});}});
    ncaa.forEach(g=>{if(g.win_probability){bookOddsCache[g.id]={};Object.keys(g.win_probability).forEach(t=>{bookOddsCache[g.id][t]=bkOffset(g.win_probability[t]);});}});
    setNbaGames(nba);setNcaaGames(ncaa);
    setLiveGames([...nba,...ncaa].filter(g=>g.status==="inprogress"));
  },[]);

  const addToSlip=useCallback((bet)=>{
    setBetSlip(p=>p.find(b=>b.id===bet.id)?p:[...p,bet]);
    if(bet.bookId){
      setCarts(prev=>{
        const existing=prev[bet.bookId]||[];
        if(existing.find(b=>b.id===bet.id)) return prev;
        return {...prev,[bet.bookId]:[...existing,bet]};
      });
    }
    setMainTab("slip");
  },[]);
  const removeFromSlip=(id)=>setBetSlip(p=>p.filter(b=>b.id!==id));
  const clearSlip=()=>setBetSlip([]);
  const handlePlaced=(bets,book)=>setHistory(p=>[...p,{bets,book,at:new Date().toLocaleTimeString()}]);
  const removeFromCart=(bookId,betId)=>setCarts(prev=>({...prev,[bookId]:(prev[bookId]||[]).filter(b=>b.id!==betId)}));
  const clearCart=(bookId)=>setCarts(prev=>({...prev,[bookId]:[]}));
  const placeCart=(bookId,bets,bookName)=>setHistory(p=>[...p,{bets,book:bookName,at:new Date().toLocaleTimeString()}]);

  const allWithOdds=[...nbaGames,...ncaaGames].filter(g=>g.win_probability);
  const upcoming=[...nbaGames,...ncaaGames].filter(g=>g.status==="scheduled");

  const tabs=[
    {id:"live",label:"🔴 Live"},
    {id:"games",label:"🏀 Games"},
    {id:"bestbets",label:"🎯 Best Bets"},
    {id:"slip",label:`📋 Slip${betSlip.length>0?` (${betSlip.length})`:""}`},
    {id:"books",label:"🌵 AZ Books"},
  ];

  return(
    <div style={{minHeight:"100vh",background:"#030712",color:"#f8fafc",fontFamily:"'DM Sans','Segoe UI',sans-serif",padding:"20px 16px",maxWidth:760,margin:"0 auto"}}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;600;700;800;900&family=DM+Mono:wght@500;700&display=swap');
        *{box-sizing:border-box;}
        @keyframes pulse{0%,100%{opacity:1}50%{opacity:0.35}}
        @keyframes btnPop{0%{transform:scale(1)}30%{transform:scale(1.18)}60%{transform:scale(0.94)}80%{transform:scale(1.06)}100%{transform:scale(1)}}
        button:hover{opacity:0.85;}
        input:focus{outline:none;}
        ::-webkit-scrollbar{height:3px;width:3px}
        ::-webkit-scrollbar-track{background:#030712}
        ::-webkit-scrollbar-thumb{background:#1e2d45;border-radius:2px}
      `}</style>

      {/* Header */}
      <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:20}}>
        <div style={{display:"flex",alignItems:"center",gap:12}}>
          <div style={{width:44,height:44,borderRadius:12,background:`linear-gradient(135deg,${BLUE},${BLUE_LIGHT})`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:24,boxShadow:`0 0 24px ${BLUE_GLOW}`}}>🏆</div>
          <div>
            <h1 style={{margin:0,fontSize:20,fontWeight:900,letterSpacing:"-0.03em",color:"#f8fafc"}}>Astreetover <span style={{color:BLUE_LIGHT}}>Betting</span></h1>
            <div style={{fontSize:10,color:"#374151",fontFamily:"'DM Mono',monospace",letterSpacing:"0.06em"}}>
              AI SPORTS INTELLIGENCE · {new Date().toLocaleDateString("en-US",{weekday:"short",month:"short",day:"numeric"})}
            </div>
          </div>
        </div>
        {betSlip.length>0&&<button onClick={()=>setMainTab("slip")} style={{background:`${BLUE}22`,border:`1px solid ${BLUE}44`,borderRadius:10,color:BLUE_LIGHT,padding:"8px 16px",cursor:"pointer",fontWeight:700,fontSize:13,animation:"pulse 2s infinite"}}>📋 {betSlip.length}</button>}
      </div>

      {/* Bankroll + Stat Tracker */}
      <BankrollPanel bankroll={bankroll} setBankroll={setBankroll} liveCount={liveGames.length} upcomingCount={upcoming.length}/>

      {/* Nav */}
      <div style={{display:"flex",gap:3,marginBottom:22,background:"#060912",borderRadius:12,padding:4,border:"1px solid #0d1422"}}>
        {tabs.map(tab=>(
          <button key={tab.id} onClick={()=>setMainTab(tab.id)} style={{flex:1,padding:"10px 4px",borderRadius:9,border:"none",background:mainTab===tab.id?`linear-gradient(135deg,${BLUE}44,${BLUE}22)`:"transparent",color:mainTab===tab.id?BLUE_LIGHT:"#374151",fontWeight:700,fontSize:11,cursor:"pointer",whiteSpace:"nowrap",boxShadow:mainTab===tab.id?`0 2px 12px ${BLUE_GLOW}`:"none",transition:"all 0.2s",fontFamily:"inherit",borderBottom:mainTab===tab.id?`2px solid ${BLUE_LIGHT}`:"2px solid transparent"}}>
            {tab.label}
            {tab.id==="live"&&liveGames.length>0&&<span style={{display:"inline-block",width:6,height:6,borderRadius:"50%",background:"#ef4444",marginLeft:4,verticalAlign:"middle",animation:"pulse 0.9s infinite"}}/>}
          </button>
        ))}
      </div>

      {/* Content */}
      {mainTab==="live"&&<LiveTab liveGames={liveGames} upcomingGames={upcoming} bankroll={bankroll} onAddToSlip={addToSlip}/>}
      {mainTab==="games"&&<GamesTab nbaGames={nbaGames} ncaaGames={ncaaGames} bankroll={bankroll} bookOddsCache={bookOddsCache} onAddToSlip={addToSlip}/>}
      {mainTab==="bestbets"&&<BestBetsTab allGames={allWithOdds} bankroll={bankroll} onAddToSlip={addToSlip}/>}
      {mainTab==="books"&&<BooksTab/>}
      {mainTab==="slip"&&(
        <div>
          <BookCartsView carts={carts} onRemoveFromCart={removeFromCart} onClearCart={clearCart} onPlaceCart={placeCart} bankroll={bankroll}/>
          <div style={{height:1,background:"#1e2d45",margin:"20px 0"}}/>
          <div style={{fontSize:11,color:"#374151",fontWeight:700,letterSpacing:"0.08em",marginBottom:12}}>FULL BET SLIP</div>
          <BetSlip slip={betSlip} onRemove={removeFromSlip} onClear={clearSlip} onPlace={handlePlaced}/>
          {history.length>0&&(
            <div style={{marginTop:20}}>
              <div style={{fontSize:12,color:"#374151",fontWeight:700,marginBottom:10,letterSpacing:"0.06em"}}>PLACED HISTORY</div>
              {history.map((ph,i)=>(
                <div key={i} style={{background:"#060912",border:"1px solid #1e2d45",borderRadius:8,padding:"10px 14px",marginBottom:8,fontSize:12}}>
                  <div style={{color:"#64748b"}}>{ph.at} · <span style={{color:BLUE_LIGHT}}>{ph.book}</span> · {ph.bets.length} bet{ph.bets.length!==1?"s":""}</div>
                  {ph.bets.map((b,j)=><div key={j} style={{color:"#374151",marginTop:3}}>→ {b.pick} · {b.odds} · ${b.stake}</div>)}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      <div style={{textAlign:"center",fontSize:10,color:"#0d1422",marginTop:24,paddingBottom:24}}>
        Astreetover Betting · 21+ AZ Only · Gamble Responsibly · 1-800-NEXT-STEP
      </div>
    </div>
  );
}
