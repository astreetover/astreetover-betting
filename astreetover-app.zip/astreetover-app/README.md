# 🏆 Astreetover Betting

AI-powered sports betting intelligence for NBA & NCAA Men's Basketball.

---

## 🚀 Deploy in 5 Minutes (Free)

### Step 1 — Get the code on GitHub
1. Go to [github.com](https://github.com) and create a free account
2. Click **"New repository"** → name it `astreetover-betting` → click **Create**
3. Click **"uploading an existing file"**
4. Drag the entire `astreetover-app` folder contents into the upload area
5. Click **"Commit changes"**

### Step 2 — Deploy to Vercel (free hosting)
1. Go to [vercel.com](https://vercel.com) and sign up with your GitHub account
2. Click **"Add New Project"** → select your `astreetover-betting` repo
3. Leave all settings as default → click **"Deploy"**
4. In ~60 seconds you get a live URL like `astreetover-betting.vercel.app`

**That's it.** Share that URL with anyone.

---

## 📱 Install as iPhone App (looks like a real app)

1. Open your Vercel URL in **Safari** on iPhone
2. Tap the **Share button** (box with arrow)
3. Scroll down → tap **"Add to Home Screen"**
4. Name it **Astreetover** → tap **Add**

It now launches fullscreen from your home screen like a native app — no browser bar, dark background, the works.

---

## 🤖 Make AI Picks Work 100% of the Time

The app already generates picks using a built-in local engine. To upgrade to full Claude AI analysis:

1. Get a free API key at [console.anthropic.com](https://console.anthropic.com)
2. Open `src/App.jsx`
3. Find the `callClaude` function (around line 146)
4. Add your key to the headers:
```js
headers: {
  "Content-Type": "application/json",
  "x-api-key": "YOUR_KEY_HERE",        // ← add this line
  "anthropic-version": "2023-06-01",   // ← add this line
}
```
5. Redeploy to Vercel (it auto-redeploys when you push to GitHub)

Cost: ~$5-10/month for regular daily use.

---

## 🔄 Keeping Games Updated

The game data in `src/App.jsx` is currently seeded for the week of Mar 23-27, 2026.
To update it weekly, find the `useEffect` in the `App` component and update the `nba` and `ncaa` arrays with the current schedule.

In a future version this can be automated with a live sports data API.

---

## 📁 File Structure

```
astreetover-app/
├── index.html          ← App entry, PWA meta tags
├── vite.config.js      ← Build config
├── package.json        ← Dependencies
├── public/
│   └── manifest.json   ← PWA manifest (home screen install)
└── src/
    ├── main.jsx        ← React mount point
    └── App.jsx         ← The entire app (betting dashboard)
```

---

## ⚠️ Legal

Must be 21+ and physically located in Arizona to place real-money bets.
For entertainment purposes. Gamble responsibly.
Problem gambling help: **1-800-NEXT-STEP**
